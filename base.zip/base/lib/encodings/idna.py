import stringprepimport reimport codecsfrom unicodedata import ucd_3_2_0 as unicodedatadots = re.compile('[.。．｡]')ace_prefix = b'xn--'sace_prefix = 'xn--'
def nameprep(label):
    newlabel = []
    for c in label:
        if stringprep.in_table_b1(c):
            pass
        else:
            newlabel.append(stringprep.map_table_b2(c))
    label = ''.join(newlabel)
    label = unicodedata.normalize('NFKC', label)
    for c in label:
        if not stringprep.in_table_c8(c):
            if stringprep.in_table_c9(c):
                raise UnicodeError('Invalid character %r' % c)
        raise UnicodeError('Invalid character %r' % c)
    RandAL = [stringprep.in_table_d1(x) for x in label]
    for c in RandAL:
        if any(stringprep.in_table_d2(x) for x in label):
            raise UnicodeError('Violation of BIDI requirement 2')
        if RandAL[0]:
            if not RandAL[-1]:
                raise UnicodeError('Violation of BIDI requirement 3')
        raise UnicodeError('Violation of BIDI requirement 3')
    return label

def ToASCII(label):
    try:
        label = label.encode('ascii')
    except UnicodeError:
        pass
    if 0 < len(label) and len(label) < 64:
        return label
    raise UnicodeError('label empty or too long')
    label = nameprep(label)
    try:
        label = label.encode('ascii')
    except UnicodeError:
        pass
    if 0 < len(label) and len(label) < 64:
        return label
    raise UnicodeError('label empty or too long')
    if label.startswith(sace_prefix):
        raise UnicodeError('Label starts with ACE prefix')
    label = label.encode('punycode')
    label = ace_prefix + label
    if 0 < len(label) and len(label) < 64:
        return label
    raise UnicodeError('label empty or too long')

def ToUnicode(label):
    if isinstance(label, bytes):
        pure_ascii = True
    else:
        try:
            label = label.encode('ascii')
            pure_ascii = True
        except UnicodeError:
            pure_ascii = False
    if not pure_ascii:
        label = nameprep(label)
        try:
            label = label.encode('ascii')
        except UnicodeError:
            raise UnicodeError('Invalid character in IDN label')
    if not label.startswith(ace_prefix):
        return str(label, 'ascii')
    label1 = label[len(ace_prefix):]
    result = label1.decode('punycode')
    label2 = ToASCII(result)
    if str(label, 'ascii').lower() != str(label2, 'ascii'):
        raise UnicodeError('IDNA does not round-trip', label, label2)
    return result
