
class TunableMinimumLengthError(ValueError):
    pass
