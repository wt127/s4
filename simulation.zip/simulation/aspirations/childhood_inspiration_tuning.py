import sims4from sims4.tuning.tunable import TunableEnumSet
class ChildhoodInspirationTuning:
    REFRESH_TIME = sims4.tuning.tunable.Tunable(description='\n        Duration in sim hours to refresh the suggested challenge.\n        ', tunable_type=int, default=90)
    MAX_NUM_OF_VISIBLE_SUGGESTED_INSPIRATION = sims4.tuning.tunable.Tunable(description='\n        Number of suggested inspirations displayed in the childhood inspiration panel.\n        ', tunable_type=int, default=5)
    COOLDOWN_TIME = sims4.tuning.tunable.Tunable(description='\n        cool down time in sim hour for the active challenge that is removed by player, or removed from suggested list\n        that can be suggested again.\n        ', tunable_type=int, default=90)
    MAX_NUM_OF_ACTIVE_CHILDHOOD_INSPIRATION = sims4.tuning.tunable.Tunable(description='\n        Max number of active childhood inspirations displayed in the childhood inspiration panel.\n        ', tunable_type=int, default=5)
