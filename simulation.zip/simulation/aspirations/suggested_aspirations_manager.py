from __future__ import annotationsfrom protocolbuffers.DistributorOps_pb2 import Operationfrom distributor.ops import GenericProtocolBufferOpfrom distributor.system import Distributorfrom typing import TYPE_CHECKINGif TYPE_CHECKING:
    from typing import *
    from aspirations.aspirations import AspirationTrackerfrom _collections import dequeimport alarmsimport servicesimport sims4.logfrom aspirations.childhood_inspiration_tuning import ChildhoodInspirationTuningfrom aspirations.timed_aspiration import TimedAspirationfrom date_and_time import create_time_span, DateAndTimefrom distributor.rollback import ProtocolBufferRollbackfrom protocolbuffers import SimObjectAttributes_pb2, Sims_pb2logger = sims4.log.Logger('Aspirations')
class SuggestedAspirationsManager:

    def __init__(self, tracker):
        self._tracker = tracker
        self._visible_suggested_aspirations = []
        self._invisible_suggested_aspirations = deque()
        self._cool_down_aspirations_dict = {}
        self._refresh_suggested_aspiration_alarm_handle = None

    def set_tracker(self, tracker:'AspirationTracker') -> 'None':
        self._tracker = tracker

    def save(self, msg:'SimObjectAttributes_pb2.SuggestedAspiration') -> 'None':
        msg.visible_suggested_aspirations.extend([aspiration.guid64 for aspiration in self._visible_suggested_aspirations])
        msg.invisible_suggested_aspirations.extend([aspiration.guid64 for aspiration in self._invisible_suggested_aspirations])
        for (aspiration, time) in self._cool_down_aspirations_dict.items():
            with ProtocolBufferRollback(msg.cool_down_dict) as cooldown_msg:
                cooldown_msg.aspiration = aspiration.guid64
                cooldown_msg.timestamp = time.absolute_ticks()

    def load(self, msg:'SimObjectAttributes_pb2.SuggestedAspiration') -> 'None':
        if msg is not None:
            aspiration_manager = services.get_instance_manager(sims4.resources.Types.ASPIRATION)
            for aspiration_id in msg.visible_suggested_aspirations:
                aspiration = aspiration_manager.get(aspiration_id)
                if aspiration is None:
                    pass
                else:
                    self._visible_suggested_aspirations.append(aspiration)
            for aspiration_id in msg.invisible_suggested_aspirations:
                aspiration = aspiration_manager.get(aspiration_id)
                if aspiration is None:
                    pass
                else:
                    self._invisible_suggested_aspirations.append(aspiration)
            for cool_down_aspiration_data in msg.cool_down_dict:
                aspiration = aspiration_manager.get(cool_down_aspiration_data.aspiration)
                if aspiration is None:
                    pass
                else:
                    cooldown_time = DateAndTime(cool_down_aspiration_data.timestamp)
                    self._cool_down_aspirations_dict[aspiration] = cooldown_time
            self.send_suggested_aspiration_to_client()
        return True

    def clear_alarm(self) -> 'None':
        if self._refresh_suggested_aspiration_alarm_handle is not None:
            alarms.cancel_alarm(self._refresh_suggested_aspiration_alarm_handle)

    def refresh_suggested_aspiration(self, handle) -> 'None':
        if self.visible_suggested_aspiration_is_full:
            return
        while self.visible_suggested_aspiration_is_full or len(self._invisible_suggested_aspirations) > 0:
            suggested_aspiration = self._invisible_suggested_aspirations.popleft()
            if self.aspiration_needs_cooldown(suggested_aspiration) or suggested_aspiration not in self._tracker.get_active_childhood_inspirations():
                self._visible_suggested_aspirations.append(suggested_aspiration)
        self.send_suggested_aspiration_to_client()
        if len(self._invisible_suggested_aspirations) == 0:
            alarms.cancel_alarm(self._refresh_suggested_aspiration_alarm_handle)

    def add_suggested_aspiration(self, aspiration:'TimedAspiration') -> 'None':
        if aspiration is None:
            logger.error('Trying to add aspiration to suggested aspiration but aspiration:{} is None', self.interaction)
            return
        if self.aspiration_needs_cooldown(aspiration):
            return
        if aspiration in self._visible_suggested_aspirations or aspiration in self._invisible_suggested_aspirations:
            return
        if self.visible_suggested_aspiration_is_full:
            if len(self._invisible_suggested_aspirations) == 0:
                self.add_refresh_alarm()
            self._invisible_suggested_aspirations.append(aspiration)
            return
        self._visible_suggested_aspirations.append(aspiration)
        self.send_suggested_aspiration_to_client()

    def remove_suggested_aspiration(self, aspiration:'TimedAspiration', cool_down:'bool'=True) -> 'None':
        if aspiration in self._visible_suggested_aspirations:
            self._visible_suggested_aspirations.remove(aspiration)
            if cool_down:
                self._cool_down_aspirations_dict[aspiration] = services.time_service().sim_now
            self.send_suggested_aspiration_to_client()

    def add_aspiration_to_cool_down(self, aspiration:'TimedAspiration') -> 'None':
        self._cool_down_aspirations_dict[aspiration] = services.time_service().sim_now

    def activate_suggested_aspiration(self, aspiration:'TimedAspiration') -> 'None':
        self.remove_suggested_aspiration(aspiration, cool_down=False)
        self._tracker.activate_timed_aspiration(aspiration)

    @property
    def visible_suggested_aspiration_is_full(self) -> 'bool':
        return len(self._visible_suggested_aspirations) >= ChildhoodInspirationTuning.MAX_NUM_OF_VISIBLE_SUGGESTED_INSPIRATION

    def has_suggested_aspiration(self, aspiration:'TimedAspiration') -> 'bool':
        return aspiration in self._visible_suggested_aspirations or aspiration in self._invisible_suggested_aspirations

    def send_suggested_aspiration_to_client(self) -> 'None':
        if services.current_zone().is_zone_shutting_down:
            return
        owner = self._tracker.owner_sim_info
        try:
            msg = Sims_pb2.SuggestedAspirationUpdate()
        except:
            return
        msg.sim_id = owner.id
        for aspiration in self._visible_suggested_aspirations:
            msg.visible_suggested_aspiration_list.append(int(aspiration.guid64))
        distributor = Distributor.instance()
        distributor.add_op(owner, GenericProtocolBufferOp(Operation.SIM_SUGGESTED_ASPIRATION_UPDATE, msg))

    def add_refresh_alarm(self) -> 'None':
        refresh_time = create_time_span(hours=ChildhoodInspirationTuning.REFRESH_TIME)
        self._refresh_suggested_aspiration_alarm_handle = alarms.add_alarm(self, refresh_time, self.refresh_suggested_aspiration, repeating=True)
        if self._refresh_suggested_aspiration_alarm_handle is None:
            logger.error('Refresh suggested aspiration alarm creation is failed.')

    def aspiration_needs_cooldown(self, aspiration:'TimedAspiration') -> 'bool':
        if aspiration in self._cool_down_aspirations_dict.keys():
            now = services.time_service().sim_now
            refresh_time = create_time_span(hours=ChildhoodInspirationTuning.REFRESH_TIME)
            if now - self._cool_down_aspirations_dict[aspiration] >= refresh_time:
                del self._cool_down_aspirations_dict[aspiration]
                return False
            else:
                return True
        return False
