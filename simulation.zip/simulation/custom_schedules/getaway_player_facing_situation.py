from __future__ import annotationsfrom typing import TYPE_CHECKINGif TYPE_CHECKING:
    from protocolbuffers.Situations_pb2 import SituationStart, SituationTimeUpdate
    from sims.sim_info import SimInfo
    from situations.situation_job import SituationJob
    from travel_group.travel_group_getaway import TravelGroupGetaway
    from typing import List, Optional, Tuplefrom protocolbuffers import FileSerialization_pb2from sims4.utils import classpropertyfrom situations.situation_types import SituationDisplayType, SituationSerializationOptionfrom situations.situation_complex import SituationComplexCommon, SituationStateData, TunableSituationJobAndRoleState, SituationStateimport servicesimport telemetry_helperimport sims4TELEMETRY_GROUP_SITUATIONS = 'SITU'TELEMETRY_HOOK_START_SITUATION = 'STOS'TELEMETRY_FIELD_SITUATION_GETAWAY_TYPE = 'gatp'writer = sims4.telemetry.TelemetryWriter(TELEMETRY_GROUP_SITUATIONS)
class _ActiveGetawayState(SituationState):
    pass

class GetawayPlayerFacingSituation(SituationComplexCommon):
    INSTANCE_TUNABLES = {'participant_job_and_role_state': TunableSituationJobAndRoleState(description='\n            Job and Role State for the participant.\n            ')}

    @classmethod
    def _states(cls) -> 'Tuple[SituationStateData, ...]':
        return [SituationStateData(1, _ActiveGetawayState)]

    @property
    def situation_display_type(self) -> 'SituationDisplayType':
        return SituationDisplayType.GETAWAY

    @classmethod
    def _get_tuned_job_and_default_role_state_tuples(cls) -> 'List':
        return [(cls.participant_job_and_role_state.job, cls.participant_job_and_role_state.role_state)]

    @classmethod
    def default_job(cls) -> 'SituationJob':
        return cls.participant_job_and_role_state.job

    @classproperty
    def allow_non_prestige_events(cls) -> 'bool':
        return True

    @classproperty
    def situation_serialization_option(cls):
        return SituationSerializationOption.DONT

    @classmethod
    def get_possible_zone_ids_for_situation(cls, host_sim_info:'Optional[SimInfo]'=None, guest_ids:'Optional[List[int]]'=None) -> 'List[int]':
        venue_service = services.current_zone().venue_service
        return venue_service.get_zones_for_venue_type_gen(*cls.compatible_venues)

    def start_situation(self) -> 'None':
        with telemetry_helper.begin_hook(writer, TELEMETRY_HOOK_START_SITUATION) as hook:
            zone_id = self.zone_id
            if zone_id is not None:
                hook.write_int(TELEMETRY_FIELD_SITUATION_GETAWAY_TYPE, zone_id)
        super().start_situation()
        self._change_state(_ActiveGetawayState())

    def pre_destroy(self) -> 'None':
        custom_schedule_service = services.custom_schedule_service()
        if custom_schedule_service:
            custom_schedule_service.send_situation_update_active_schedule(self)

    def on_added_to_distributor(self) -> 'None':
        super().on_added_to_distributor()
        custom_schedule_service = services.custom_schedule_service()
        if custom_schedule_service:
            custom_schedule_service.send_situation_update_active_schedule(self)

    def _get_travel_group(self) -> 'Optional[TravelGroupGetaway]':
        active_household = services.active_household()
        if active_household is None:
            return
        else:
            travel_group = services.travel_group_manager().get_travel_group_by_household(active_household)
            if travel_group is not None and travel_group.group_type == FileSerialization_pb2.TravelGroupData.GROUPTYPE_GETAWAY:
                return travel_group

    def build_situation_start_message(self) -> 'SituationStart':
        start_msg = super().build_situation_start_message()
        custom_schedule_service = services.custom_schedule_service()
        if custom_schedule_service is not None:
            active_schedule = custom_schedule_service.active_getaway_schedule
            if active_schedule is not None:
                start_msg.custom_schedule = active_schedule.get_proto_msg()
            travel_group = self._get_travel_group()
            if travel_group is not None:
                start_msg.start_time = travel_group.get_creation_time()
                start_msg.end_time = travel_group.end_timestamp
        return start_msg

    def build_situation_duration_change_op(self) -> 'SituationTimeUpdate':
        duration_msg = super().build_situation_duration_change_op()
        travel_group = self._get_travel_group()
        if travel_group is not None:
            duration_msg.end_time = travel_group.end_timestamp
        return duration_msg
