from __future__ import annotationsfrom filters.tunable import AgeVariationFilterTermfrom objects import ALL_HIDDEN_REASONS_EXCEPT_UNINITIALIZEDfrom typing import TYPE_CHECKINGif TYPE_CHECKING:
    from clubs.club_tuning import ClubInteractionGroup
    from custom_schedules.custom_schedule import CustomSchedule
    from custom_schedules.custom_schedule_data_classes import GetawayChallengeGroupData, TimeSlotAssignmentData
    from filters.tunable import BaseFilterTerm
    from protocolbuffers import CustomSchedule_pb2
    from sims.sim_info import SimInfo
    from statistics.statistic import Statistic
    from typing import *import alarmsimport randomimport servicesimport sims4.resourcesfrom buffs.tunable import TunableBuffReferencefrom custom_schedules.custom_schedule_tuning import CustomScheduleTuningfrom date_and_time import create_time_spanfrom event_testing.resolver import GlobalResolver, Resolver, SingleSimResolverfrom event_testing.tests import TunableTestSetfrom objects import ALL_HIDDEN_REASONS_EXCEPT_UNINITIALIZEDfrom relationships.relationship_track import RelationshipTrackfrom sims.sim_info_types import Age, SpeciesExtendedfrom sims4.localization import TunableLocalizedStringFactoryfrom sims4.log import Loggerfrom sims4.resources import Types, CompoundTypesfrom sims.sim_info_types import Speciesfrom sims4.tuning.instances import HashedTunedInstanceMetaclassfrom sims4.tuning.tunable import OptionalTunable, TunableResourceKey, TunableList, TunableTuple, TunableEnumSet, Tunable, TunablePackSafeReference, TunableReferencefrom sims4.tuning.tunable_base import GroupNamesfrom situations.bouncer.bouncer_types import RequestSpawningOption, BouncerRequestPriorityfrom situations.situation_guest_list import SituationGuestList, SituationGuestInfofrom tunable_time import TunableTimeOfDayfrom ui.ui_dialog_notification import UiDialogNotificationfrom ui.ui_dialog_picker import SimPickerRow, UiSimPickerlogger = Logger('CustomSchedules', default_owner='cparrish')
class GetawayChallenge(metaclass=HashedTunedInstanceMetaclass, manager=services.get_instance_manager(Types.GETAWAY_CHALLENGE)):
    INSTANCE_TUNABLES = {'display_name': TunableLocalizedStringFactory(description='\n            The challenge will display in the UI with this string.\n            ', tuning_group=GroupNames.UI), 'description_tooltip': TunableLocalizedStringFactory(description='\n            Description of this challenge.\n            ', tuning_group=GroupNames.UI), 'icon': TunableResourceKey(description='\n            The challenge will display in the UI using this icon.\n            ', tuning_group=GroupNames.UI, resource_types=CompoundTypes.IMAGE), 'groups': TunableList(description='\n            A single challenge may apply different behaviors to different roles. A role may\n            only belong to a single group.\n            ', tunable=TunableTuple(disallowed_ages=TunableEnumSet(description='\n                    Selected sims in this group must be an allowed age for this challenge to\n                    apply. The UI will make weak attempts at enforcing this requirement.\n                    ', enum_type=Age, enum_default=None, allow_none=True), disallowed_species=TunableEnumSet(description='\n                    Selected sims in this group must be an allowed species for this challenge to\n                    apply. The UI will make weak attempts at enforcing this requirement.\n                    ', enum_type=SpeciesExtended, enum_default=None, allow_none=True), group_name=TunableLocalizedStringFactory(description='\n                    The display name of this group of roles. Used in the UI as a header\n                    for each group of roles.\n                    ', tuning_group=GroupNames.UI), multi_select=Tunable(description='\n                    If True, multiple roles are allowed to be selected. Otherwise only a\n                    single role may be selected.\n                    ', tunable_type=bool, default=True), associated_buff=TunableList(description='\n                    The list of buffs associated with the role selected by the player.\n                    ', tunable=TunableBuffReference(description='\n                        The buff associated with the role selected by the player.\n                        A Sim of Interest requires a unique buff to be identified.\n                        ', pack_safe=True))))}
    is_elimination_challenge = False

    def __init__(self, current_schedule:'CustomSchedule', challenge_groups:'List[GetawayChallengeGroupData]', *args, **kwargs) -> 'None':
        super().__init__(*args, **kwargs)
        self._current_schedule = current_schedule
        self._assignments_to_buffs = {}
        self._sim_ids_to_buffs = {}
        for group in challenge_groups:
            if group.group_id != 0 and group.group_id <= len(self.groups):
                if hasattr(group, 'assignment_ids'):
                    for assignment_identifier in group.assignment_ids:
                        if assignment_identifier not in self._assignments_to_buffs:
                            self._assignments_to_buffs[assignment_identifier] = list(self.groups[group.group_id - 1].associated_buff)
                        else:
                            self._assignments_to_buffs[assignment_identifier].extend(self.groups[group.group_id - 1].associated_buff)
                else:
                    for assignment_identifier in group.assignment_names:
                        if assignment_identifier not in self._assignments_to_buffs:
                            self._assignments_to_buffs[assignment_identifier] = list(self.groups[group.group_id - 1].associated_buff)
                        else:
                            self._assignments_to_buffs[assignment_identifier].extend(self.groups[group.group_id - 1].associated_buff)
            else:
                logger.error("Challenge group {} has group id {} which is not in range of the {} challenge's list of groups.", str(group), group.group_id, len(self.groups))

    def on_sim_added(self, sim_id:'int', assignment:'TimeSlotAssignmentData') -> 'None':
        self.on_sim_removed(sim_id)
        buffs = self._assignments_to_buffs.get(assignment.id)
        if buffs is None:
            for assignment_preset in self._current_schedule.assignment_presets:
                if assignment_preset.id == assignment.id:
                    buffs = self._assignments_to_buffs.get(assignment_preset.display_name)
                    break
        if buffs is not None:
            sim_info = services.sim_info_manager().get(sim_id)
            if sim_info.id not in self._sim_ids_to_buffs:
                self._sim_ids_to_buffs[sim_info.id] = set()
            for buff in buffs:
                if sim_info.add_buff(buff.buff_type, buff.buff_reason):
                    self._sim_ids_to_buffs[sim_info.id].add(buff.buff_type)

    def on_sim_removed(self, sim_id:'int') -> 'None':
        if sim_id in self._sim_ids_to_buffs:
            sim_info = services.sim_info_manager().get(sim_id)
            buffs = self._sim_ids_to_buffs.pop(sim_info.sim_id)
            for buff in buffs:
                sim_info.remove_buff_by_type(buff)

    def get_sims_in_challenge(self) -> 'Set[SimInfo]':
        if not self.groups:
            return self._current_schedule.get_siminfos_active_in_time_slot()
        sim_info_manager = services.sim_info_manager()
        sims_in_challenge = set()
        for associated_sim_id in self._sim_ids_to_buffs:
            associated_sim_info = sim_info_manager.get(associated_sim_id)
            if associated_sim_info is None:
                pass
            else:
                sims_in_challenge.add(associated_sim_info)
        return sims_in_challenge

    def get_filter_term(self, assignment_id:'int', assignment_name:'str') -> 'Optional[BaseFilterTerm]':
        relevant_buffs = self._assignments_to_buffs.get(assignment_name)
        if relevant_buffs is None:
            relevant_buffs = self._assignments_to_buffs.get(assignment_id)
            if relevant_buffs is None:
                return
        allowed_ages = set(Age)
        for group in self.groups:
            if set(group.associated_buff) == set(relevant_buffs):
                allowed_ages.difference_update(group.disallowed_ages)
        return AgeVariationFilterTerm(minimum_filter_score=0, force_filter_term=True, allowed_ages=allowed_ages)

    def on_getaway_start(self, is_new_getaway:'bool') -> 'None':
        pass

    def on_getaway_end(self):
        pass

class GetawayChallengeWithDailyTimer(GetawayChallenge):
    INSTANCE_TUNABLES = {'daily_timer': TunableTimeOfDay(description='\n            Unique behavior is triggered at this time every day of the Getaway.\n            '), 'daily_timer_notification': OptionalTunable(description="\n            A TNS that is displayed upon the daily timer.\n            \n            Deprecated: it's preferred to use Loot Before Daily Timer or\n            Loot After Daily Timer instead.\n            ", tunable=UiDialogNotification.TunableFactory(), deprecated=True), 'tests_blocking_daily_timer_behavior': TunableTestSet(description='\n           Blocks daily timer behavior if one of these tuned tests passes.\n           \n           Loots Before/After Daily Timer will run regardless of this.\n           '), 'loots_before_daily_timer': TunableList(description="\n            Loot operations that occur before this challenge's unique Daily Timer behavior runs.\n            \n            Participants for this loot differ based on the challenge - for eliminations, the eliminated sim is actor.\n            Consult GPE for more participant info.\n            ", tunable=TunableReference(manager=services.get_instance_manager(sims4.resources.Types.ACTION), class_restrictions=('LootActions',), pack_safe=True)), 'loots_after_daily_timer': TunableList(description="\n            Loot operations that occur after this challenge's unique Daily Timer behavior has completed.\n            \n            Participants for this loot differ based on the challenge - for eliminations, the eliminated sim is actor.\n            Consult GPE for more participant info.\n            ", tunable=TunableReference(manager=services.get_instance_manager(sims4.resources.Types.ACTION), class_restrictions=('LootActions',), pack_safe=True))}

    def __init__(self, *args, **kwargs) -> 'None':
        super().__init__(*args, **kwargs)
        self._daily_alarm_handle = None

    def _run_loots_before_daily_timer_behavior(self, resolver:'Resolver') -> 'None':
        for loot_action in self.loots_before_daily_timer:
            loot_action.apply_to_resolver(resolver)

    def _should_run_daily_timer(self, resolver:'Resolver') -> 'bool':
        if self.tests_blocking_daily_timer_behavior:
            test_result = self.tests_blocking_daily_timer_behavior.run_tests(resolver)
            if test_result:
                return False
        return True

    def _run_loots_after_daily_timer_behavior(self, resolver:'Resolver') -> 'None':
        for loot_action in self.loots_after_daily_timer:
            loot_action.apply_to_resolver(resolver)

    def on_daily_timer(self, *_, **__) -> 'None':
        resolver = GlobalResolver()
        self._run_loots_before_daily_timer_behavior(resolver)
        self._run_loots_after_daily_timer_behavior(resolver)

    def on_getaway_start(self, is_new_getaway:'bool') -> 'None':
        now = services.time_service().sim_now
        time_until_first_alarm = now.time_till_next_day_time(self.daily_timer)
        if time_until_first_alarm < CustomScheduleTuning.GETAWAY_ELIMINATION_MINIMUM_START():
            time_until_first_alarm += create_time_span(days=1)
        self._daily_alarm_handle = alarms.add_alarm(self, time_until_first_alarm, self.on_daily_timer, repeating=True, repeating_time_span=create_time_span(days=1), cross_zone=True)

    def on_getaway_end(self) -> 'None':
        if self._daily_alarm_handle is not None:
            alarms.cancel_alarm(self._daily_alarm_handle)

class GetawayEliminationChallenge(GetawayChallengeWithDailyTimer):
    is_elimination_challenge = True
    INSTANCE_TUNABLES = {'elimination_situation': TunableReference(description='\n            This situation forces the eliminated sim off of the lot. \n            ', manager=services.get_instance_manager(sims4.resources.Types.SITUATION), class_restrictions=('SingleSimLeaveSituation',), allow_none=True)}

    def _remove_sim_from_zone(self, sim_info:'SimInfo') -> 'None':
        sim_instance = sim_info.get_sim_instance(allow_hidden_flags=ALL_HIDDEN_REASONS_EXCEPT_UNINITIALIZED)
        if services.current_zone_id() == sim_info.household.home_zone_id:
            return
        if sim_instance:
            situation_manager = services.get_zone_situation_manager()
            if self.elimination_situation is None:
                if sim_instance.household_id != services.active_household_id():
                    situation_manager.make_sim_leave_now_must_run(sim_instance)
                return
            for situation in situation_manager.get_situations_sim_is_in(sim_instance):
                if not type(situation) is self.elimination_situation:
                    if type(situation) is situation_manager.DEFAULT_LEAVE_NOW_MUST_RUN_SITUATION:
                        return
                return
            guest_list = SituationGuestList(invite_only=True)
            guest_info = SituationGuestInfo(sim_info.id, self.elimination_situation.default_job(), RequestSpawningOption.CANNOT_SPAWN, BouncerRequestPriority.EVENT_VIP, expectation_preference=True)
            guest_list.add_guest_info(guest_info)
            situation_manager.create_situation(self.elimination_situation, guest_list=guest_list, user_facing=False)
        else:
            sim_info.inject_into_inactive_zone(sim_info.household.home_zone_id, skip_instanced_check=True)

    @staticmethod
    def _is_active_elimination_candidate(sim_info:'SimInfo') -> 'bool':
        return sim_info.has_buff(CustomScheduleTuning.GETAWAY_ELIMINATION_CANDIDATE_BUFF)

    def eliminate_sim_from_getaway(self, sim:'SimInfo') -> 'None':
        if self.daily_timer_notification is not None:
            notification = self.daily_timer_notification(sim, resolver=SingleSimResolver(sim))
            notification.show_dialog()
        self._current_schedule.getaway_travel_group.remove_sim_info(sim, decrement_sim_count=True)
        self._remove_sim_from_zone(sim)
        custom_schedule_service = services.custom_schedule_service()
        active_schedule = custom_schedule_service.active_getaway_schedule
        if active_schedule is None:
            return
        travel_group = active_schedule.getaway_travel_group
        if travel_group is None:
            return
        services.custom_schedule_service().update_planned_schedule(active_schedule, travel_group.id, restart_schedule=False)

class PlayerElimination(GetawayEliminationChallenge):
    INSTANCE_TUNABLES = {'sim_picker': UiSimPicker.TunableFactory(description='\n            The picker dialog to show to select the sim to eliminate.\n            \n            Loots Before Daily Timer is run after player has selected a sim\n            to eliminate, but before the sim is actually eliminated.\n            ')}

    def on_daily_timer(self, *_, **__) -> 'None':
        picker_dialog = self.sim_picker(services.active_sim_info())
        for sim_info in self.get_sims_in_challenge():
            dialog_row = SimPickerRow(sim_info.sim_id, tag=sim_info)
            picker_dialog.add_row(dialog_row)

        def on_response(dialog):
            if not dialog.accepted:
                return
            selected_sim_info = dialog.get_single_result_tag()
            resolver = SingleSimResolver(selected_sim_info) if selected_sim_info is not None else GlobalResolver()
            self._run_loots_before_daily_timer_behavior(resolver)
            if self._should_run_daily_timer(resolver):
                self.eliminate_sim_from_getaway(selected_sim_info)
            self._run_loots_after_daily_timer_behavior(resolver)

        picker_dialog.show_dialog(on_response=on_response)
        return True

class TrackEliminationChallenge(GetawayEliminationChallenge):

    def __init__(self, *args, **kwargs) -> 'None':
        super().__init__(*args, **kwargs)
        self._delta_statistic = CustomScheduleTuning.GETAWAY_TRACK_CHALLENGE_STAT

    def _reset_competitor_tracker_statistics(self) -> 'None':
        sims_in_challenge = self.get_sims_in_challenge()
        for competitor in sims_in_challenge:
            competitor.statistic_tracker.set_value(self._delta_statistic, 0, add=True)

    def _remove_competitor_tracker_statistics(self) -> 'None':
        sims_in_challenge = self.get_sims_in_challenge()
        for competitor in sims_in_challenge:
            competitor.statistic_tracker.remove_statistic(self._delta_statistic)

    def _on_track_watcher(self, sim_id:'int', stat_type:'Statistic', old_value:'float', new_value:'float', unclamped_target_value:'float') -> 'None':
        self._on_delta_track_watcher(sim_id, stat_type, unclamped_target_value - old_value)

    def _on_delta_track_watcher(self, sim_id:'int', stat_type:'Statistic', stat_delta:'float') -> 'None':
        if not self._is_relevant_stat(stat_type):
            return
        sim_info = services.sim_info_manager().get(sim_id)
        if sim_info is not None:
            statistic_tracker = sim_info.statistic_tracker
            if statistic_tracker.has_statistic(self._delta_statistic):
                statistic_tracker.add_value(self._delta_statistic, stat_delta)

    def _add_watchers_to_stat_trackers(self) -> 'None':
        raise NotImplementedError

    def _end_watchers_for_stat_trackers(self) -> 'None':
        raise NotImplementedError

    def _is_relevant_stat(self, stat_type:'Statistic') -> 'bool':
        raise NotImplementedError

    def on_getaway_start(self, is_new_getaway:'bool') -> 'None':
        if not self._current_schedule.use_current_track_values:
            if self._delta_statistic is None:
                logger.error('Cannot run elimination challenge {}, missing elimination statistic', self)
                return
            if is_new_getaway:
                self._reset_competitor_tracker_statistics()
            self._add_watchers_to_stat_trackers()
        super().on_getaway_start(is_new_getaway)

    def on_getaway_end(self) -> 'None':
        if not self._current_schedule.use_current_track_values:
            self._remove_competitor_tracker_statistics()
            self._end_watchers_for_stat_trackers()
        super().on_getaway_end()

    def get_worst_competitor(self) -> 'Optional[SimInfo]':
        if self._current_schedule.use_current_track_values:
            raise NotImplementedError('{} needs subclass implementation for get_worst_competitor to handle using current track values'.format(self))
        sims_in_challenge = self.get_sims_in_challenge()
        if not sims_in_challenge:
            return
        (worst_competitor, worst_increase) = (None, None)
        for competitor in sims_in_challenge:
            if not self._is_active_elimination_candidate(competitor):
                pass
            else:
                statistic_tracker = competitor.statistic_tracker
                competitor_increase = statistic_tracker.get_value(self._delta_statistic)
                if not worst_increase is None:
                    if competitor_increase < worst_increase:
                        worst_competitor = competitor
                        worst_increase = competitor_increase
                worst_competitor = competitor
                worst_increase = competitor_increase
        return worst_competitor

    def on_daily_timer(self, *_, **__) -> 'None':
        worst_competitor = self.get_worst_competitor()
        resolver = SingleSimResolver(worst_competitor) if worst_competitor is not None else GlobalResolver()
        self._run_loots_before_daily_timer_behavior(resolver)
        if self._should_run_daily_timer(resolver):
            if worst_competitor is not None:
                self.eliminate_sim_from_getaway(worst_competitor)
            if not self._current_schedule.use_current_track_values:
                self._reset_competitor_tracker_statistics()
        self._run_loots_after_daily_timer_behavior(resolver)

    def eliminate_sim_from_getaway(self, sim:'SimInfo') -> 'None':
        if not self._current_schedule.use_current_track_values:
            sim.statistic_tracker.remove_statistic(self._delta_statistic)
        super().eliminate_sim_from_getaway(sim)

class SkillElimination(TrackEliminationChallenge):
    INSTANCE_TUNABLES = {'skills': TunableList(tunable=TunableReference(manager=services.get_instance_manager(Types.STATISTIC), class_restrictions=('Skill',), pack_safe=True))}

    def __init__(self, *args, **kwargs) -> 'None':
        super().__init__(*args, **kwargs)
        self._skill_track_watchers = {}

    def _add_watchers_to_stat_trackers(self) -> 'None':
        sims_in_challenge = self.get_sims_in_challenge()
        for competitor in sims_in_challenge:
            if not self._is_active_elimination_candidate(competitor):
                pass
            else:
                track = competitor.statistic_component.get_commodity_tracker()
                watcher_callback = lambda stat_type, old_val, new_val, unclamp_val, sim_id=competitor.sim_id: self._on_track_watcher(sim_id, stat_type, old_val, new_val, unclamp_val)
                delta_watcher_callback = lambda stat_type, delta, sim_id=competitor.sim_id: self._on_delta_track_watcher(sim_id, stat_type, delta)
                self._skill_track_watchers[competitor.sim_id] = (track.add_unclamped_watcher(watcher_callback), track.add_delta_watcher(delta_watcher_callback))

    def _end_watchers_for_stat_trackers(self) -> 'None':
        sim_info_manager = services.sim_info_manager()
        for (sim_id, watcher_id_tuple) in self._skill_track_watchers.items():
            competitor = sim_info_manager.get(sim_id)
            track = competitor.statistic_component.get_commodity_tracker()
            if track is not None:
                track.remove_unclamped_watcher(watcher_id_tuple[0])
                track.remove_delta_watcher(watcher_id_tuple[1])
        self._skill_track_watchers = {}

    def _is_relevant_stat(self, stat_type:'Statistic') -> 'bool':
        return stat_type in self.skills

    def eliminate_sim_from_getaway(self, sim:'SimInfo') -> 'None':
        if sim.sim_id in self._skill_track_watchers:
            watcher_id_tuple = self._skill_track_watchers[sim.sim_id]
            track = sim.statistic_component.get_commodity_tracker()
            if track is not None:
                track.remove_unclamped_watcher(watcher_id_tuple[0])
                track.remove_delta_watcher(watcher_id_tuple[1])
            del self._skill_track_watchers[sim.sim_id]
        super().eliminate_sim_from_getaway(sim)

    def get_worst_competitor(self) -> 'Optional[SimInfo]':
        if not self._current_schedule.use_current_track_values:
            return super().get_worst_competitor()
        sims_in_challenge = self.get_sims_in_challenge()
        if not sims_in_challenge:
            return
        (worst_competitor, worst_total_skills) = (None, None)
        for competitor in sims_in_challenge:
            if not self._is_active_elimination_candidate(competitor):
                pass
            else:
                competitor_total_skill_values = sum(competitor.get_tracker(relevant_skill).get_user_value(relevant_skill) for relevant_skill in self.skills)
                if not worst_total_skills is None:
                    if competitor_total_skill_values < worst_total_skills:
                        worst_competitor = competitor
                        worst_total_skills = competitor_total_skill_values
                worst_competitor = competitor
                worst_total_skills = competitor_total_skill_values
        return worst_competitor

class RelationshipElimination(TrackEliminationChallenge):

    def __init__(self, *args, **kwargs) -> 'None':
        super().__init__(*args, **kwargs)
        self._relationship_track_type = None
        self._relationship_track_watchers = {}

    def _add_watchers_to_stat_trackers(self) -> 'None':
        relationship_service = services.relationship_service()
        sims_in_challenge = self.get_sims_in_challenge()
        for competitor_a in sims_in_challenge:
            if not self._is_active_elimination_candidate(competitor_a):
                pass
            else:
                for competitor_b in sims_in_challenge:
                    if not competitor_b.has_buff(CustomScheduleTuning.GETAWAY_SIMS_OF_INTEREST_BUFF):
                        pass
                    else:
                        sim_id_a = competitor_a.sim_id
                        sim_id_b = competitor_b.sim_id
                        if sim_id_a == sim_id_b:
                            pass
                        else:
                            track = relationship_service.get_relationship_track(sim_id_a, sim_id_b, self._relationship_track_type, add=True)
                            if track is None:
                                logger.warn('Unable to track relationship between {} and {} in elimination challenge', competitor_a, competitor_b)
                            else:
                                watcher_callback = lambda stat_type, old_val, new_val, unclamp_val, sim_id=sim_id_a: self._on_track_watcher(sim_id, stat_type, old_val, new_val, unclamp_val)
                                self._relationship_track_watchers[(sim_id_a, sim_id_b)] = track.tracker.add_unclamped_watcher(watcher_callback)

    def _end_watchers_for_stat_trackers(self) -> 'None':
        relationship_service = services.relationship_service()
        for ((sim_id_a, sim_id_b), watcher_id) in self._relationship_track_watchers.items():
            track = relationship_service.get_relationship_track(sim_id_a, sim_id_b, self._relationship_track_type)
            if track is not None:
                track.tracker.remove_unclamped_watcher(watcher_id)
        self._relationship_track_watchers = {}

    def _is_relevant_stat(self, stat_type:'Statistic') -> 'bool':
        return stat_type is self._relationship_track_type

    def eliminate_sim_from_getaway(self, sim:'SimInfo') -> 'None':
        relationship_service = services.relationship_service()
        for ((sim_id_a, sim_id_b), watcher_id) in list(self._relationship_track_watchers.items()):
            if sim_id_a != sim.sim_id and sim_id_b != sim.sim_id:
                pass
            else:
                track = relationship_service.get_relationship_track(sim_id_a, sim_id_b, self._relationship_track_type)
                if track is not None:
                    track.tracker.remove_unclamped_watcher(watcher_id)
                del self._relationship_track_watchers[(sim_id_a, sim_id_b)]
        super().eliminate_sim_from_getaway(sim)

    def get_worst_competitor(self) -> 'Optional[SimInfo]':
        if not self._current_schedule.use_current_track_values:
            return super().get_worst_competitor()
        relationship_service = services.relationship_service()
        sims_in_challenge = self.get_sims_in_challenge()
        (worst_competitor, worst_avg_relationship) = (None, None)
        for competitor_a in sims_in_challenge:
            if not self._is_active_elimination_candidate(competitor_a):
                pass
            else:
                competitor_a_total_score = 0
                num_relationships = 0
                for competitor_b in sims_in_challenge:
                    if not competitor_b.has_buff(CustomScheduleTuning.GETAWAY_SIMS_OF_INTEREST_BUFF):
                        pass
                    else:
                        sim_id_a = competitor_a.sim_id
                        sim_id_b = competitor_b.sim_id
                        if sim_id_a == sim_id_b:
                            pass
                        else:
                            track = relationship_service.get_relationship_track(sim_id_a, sim_id_b, self._relationship_track_type, add=True)
                            if track is None:
                                pass
                            else:
                                competitor_a_total_score += track.get_value()
                                num_relationships += 1
                avg_relationship = None if num_relationships == 0 else competitor_a_total_score/num_relationships
                if not avg_relationship is None:
                    if avg_relationship < worst_avg_relationship:
                        worst_competitor = competitor_a
                        worst_avg_relationship = avg_relationship
                worst_competitor = competitor_a
                worst_avg_relationship = avg_relationship
        return worst_competitor

class FriendshipElimination(RelationshipElimination):

    def __init__(self, *args, **kwargs) -> 'None':
        super().__init__(*args, **kwargs)
        self._relationship_track_type = RelationshipTrack.FRIENDSHIP_TRACK

class RomanceElimination(RelationshipElimination):

    def __init__(self, *args, **kwargs) -> 'None':
        super().__init__(*args, **kwargs)
        self._relationship_track_type = RelationshipTrack.ROMANCE_TRACK

class ActivityShuffle(GetawayChallengeWithDailyTimer):

    def _get_activity_shuffle_candidate(self, base_activity:'ClubInteractionGroup', previous_time_slot_activity:'Optional[ClubInteractionGroup]') -> 'Optional[ClubInteractionGroup]':
        club_interaction_manager = services.get_instance_manager(sims4.resources.Types.CLUB_INTERACTION_GROUP)
        all_activities = list(club_interaction_manager.types.values())
        random.shuffle(all_activities)
        for alternate_behavior in all_activities:
            if alternate_behavior.category is not base_activity.category:
                pass
            elif not alternate_behavior.custom_schedule_enabled:
                pass
            elif not alternate_behavior.custom_schedule_enabled.shufflable:
                pass
            elif previous_time_slot_activity is not None and alternate_behavior.guid64 is previous_time_slot_activity.guid64:
                pass
            elif alternate_behavior.guid64 is base_activity.guid64:
                pass
            else:
                return alternate_behavior()

    def on_daily_timer(self, *_, **__) -> 'None':
        resolver = GlobalResolver()
        self._run_loots_before_daily_timer_behavior(resolver)
        if self._should_run_daily_timer(resolver):
            for (i, time_slot) in enumerate(self._current_schedule.time_slots):
                fallback_behavior = self._current_schedule.get_fallback_behavior(time_slot)
                if not fallback_behavior:
                    pass
                else:
                    previous_time_slot = self._current_schedule.time_slots[i - 1]
                    previous_time_slot_behavior = self._current_schedule.get_fallback_behavior(previous_time_slot)
                    chosen_candidate = self._get_activity_shuffle_candidate(fallback_behavior, previous_time_slot_behavior)
                    if not chosen_candidate:
                        pass
                    else:
                        self._current_schedule.set_activity_shuffle(i, chosen_candidate)
            travel_group = self._current_schedule.getaway_travel_group
            if travel_group is not None:
                travel_group.refresh_affordance_goals(self._current_schedule)
            services.custom_schedule_service().send_all_situation_update_active_schedule()
        self._run_loots_after_daily_timer_behavior(resolver)

    def on_getaway_start(self, is_new_getaway:'bool') -> 'None':
        super().on_getaway_start(is_new_getaway)

    def on_getaway_end(self) -> 'None':
        self._current_schedule.clear_activity_shuffles()
        super().on_getaway_end()

class BuffChallenge(GetawayChallenge):
    pass
