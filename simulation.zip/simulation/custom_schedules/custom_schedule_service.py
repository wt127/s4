from __future__ import annotationsimport id_generatorimport randomfrom event_testing.resolver import SingleSimResolver, Resolverfrom interactions import ParticipantTypefrom objects import ALL_HIDDEN_REASONS_EXCEPT_UNINITIALIZEDfrom protocolbuffers.DistributorOps_pb2 import Operationfrom clubs.club_tuning import ClubTunablesfrom custom_schedules.custom_schedule_tuning import CustomScheduleTuningfrom distributor.rollback import ProtocolBufferRollbackfrom filters.tunable import ClubCriteriaFilterTermfrom google.protobuf import text_formatfrom services import active_sim_infofrom sims.sim_info_base_wrapper import SimInfoBaseWrapperfrom sims.sim_info_types import Age, Genderfrom situations.bouncer.bouncer_types import RequestSpawningOption, BouncerRequestPriorityfrom situations.situation import Situationfrom situations.situation_guest_list import SituationGuestList, SituationGuestInfofrom situations.situation_types import SituationDisplayType, SituationUserFacingTypefrom typing import TYPE_CHECKINGfrom distributor.ops import GenericProtocolBufferOpif TYPE_CHECKING:
    from custom_schedules.custom_schedule_preset_tuning import CustomSchedulePreset
    from custom_schedules.getaway_player_facing_situation import GetawayPlayerFacingSituation
    from sims.sim import Sim
    from sims.sim_info import SimInfo
    from statistics.static_commodity import StaticCommodity
    from travel_group.travel_group import TravelGroup
    from typing import Optional, Listimport build_buyimport distributor.opsimport servicesimport sims4.logfrom custom_schedules.custom_schedule import CustomSchedulefrom custom_schedules.custom_schedule_data_classes import ScheduleAssignmentData, CustomScheduleDatafrom distributor.system import Distributorfrom persistence_error_types import ErrorCodesfrom sims4.common import Packfrom sims4.service_manager import Servicefrom sims4.utils import classpropertyfrom singletons import DEFAULTfrom protocolbuffers import Situations_pb2, GameplaySaveData_pb2, CustomSchedule_pb2from protocolbuffers.FileSerialization_pb2 import SaveSlotData, TravelGroupDatalogger = sims4.log.Logger('CustomScheduleService', default_owner='cparrish')
class CustomScheduleService(Service):

    def __init__(self):
        self._custom_schedule_presets = dict()
        self._custom_schedule_assignment_presets = dict()
        self._scheduled_getaways = dict()
        self._active_schedule = None
        self._active_getaway_schedule = None
        self._mannequin_id = None
        self._current_schedule_zone_id = None
        self._suspended_autonomy_sims = dict()

    @property
    def active_schedule(self) -> 'Optional[CustomSchedule]':
        return self._active_schedule

    @property
    def active_getaway_schedule(self) -> 'Optional[CustomSchedule]':
        return self._active_getaway_schedule

    @property
    def mannequin_id(self) -> 'int':
        return self._mannequin_id

    @property
    def in_active_getaway_zone(self) -> 'bool':
        travel_group = self._active_schedule.getaway_travel_group if self._active_schedule else None
        return travel_group is not None and travel_group.zone_id == services.current_zone_id()

    def is_sim_suspended(self, sim_info:'SimInfo') -> 'bool':
        return sim_info.sim_id in self._suspended_autonomy_sims

    @classproperty
    def required_packs(cls):
        return (Pack.EP20,)

    def save_error_code(cls):
        return ErrorCodes.SERVICE_SAVE_FAILED_CUSTOM_SCHEDULE_SERVICE

    def load(self, **__) -> 'None':
        save_slot_data_msg = services.get_persistence_service().get_save_slot_proto_buff()
        if save_slot_data_msg.gameplay_data.HasField('custom_schedule_service'):
            proto = save_slot_data_msg.gameplay_data.custom_schedule_service
            if proto.mannequin_id:
                self._mannequin_id = proto.mannequin_id
        if self.mannequin_id is None:
            self._mannequin_id = id_generator.generate_object_id()
        for assignment_tuning in CustomScheduleTuning.PREMADE_CUSTOM_ASSIGNMENTS:
            assignment_data_class = assignment_tuning().create_data_class()
            self.add_custom_assignment_to_library(assignment_data_class)
        for schedule_tuning in CustomScheduleTuning.PREMADE_CUSTOM_SCHEDULES:
            schedule_data_class = schedule_tuning().create_data_class()
            self.add_custom_schedule_to_library(schedule_data_class)
        if save_slot_data_msg.gameplay_data.HasField('custom_schedule_service'):
            proto = save_slot_data_msg.gameplay_data.custom_schedule_service
            for assignment_proto in proto.custom_assignments:
                assignment_data = ScheduleAssignmentData.from_proto_msg(assignment_proto)
                self.add_custom_assignment_to_library(assignment_data)
            for schedule_proto in proto.custom_schedules:
                schedule_data = CustomScheduleData.from_proto_msg(schedule_proto)
                self.add_custom_schedule_to_library(schedule_data)
            for getaway_proto in proto.scheduled_getaways:
                schedule_data = CustomScheduleData.from_proto_msg(getaway_proto.schedule)
                custom_schedule = CustomSchedule(schedule_data)
                self.schedule_getaway(custom_schedule, getaway_proto.owner_id)
            if proto.HasField('current_schedule_zone_id'):
                self._current_schedule_zone_id = proto.current_schedule_zone_id

    def save(self, save_slot_data:'Optional[SaveSlotData]'=None, **__) -> 'None':
        if not hasattr(GameplaySaveData_pb2, 'PersistableCustomScheduleService'):
            return
        custom_schedule_service_proto = GameplaySaveData_pb2.PersistableCustomScheduleService()
        for assignment_data in self._custom_schedule_assignment_presets.values():
            if assignment_data.is_immutable:
                pass
            else:
                with ProtocolBufferRollback(custom_schedule_service_proto.custom_assignments) as custom_assignments_msg:
                    assignment_data.fill_proto_msg(custom_assignments_msg)
        for schedule_data in self._custom_schedule_presets.values():
            if schedule_data.is_immutable:
                pass
            else:
                with ProtocolBufferRollback(custom_schedule_service_proto.custom_schedules) as custom_schedules_msg:
                    schedule_data.fill_proto_msg(custom_schedules_msg)
        for owner_id in self._scheduled_getaways:
            schedule = self._scheduled_getaways[owner_id]
            with ProtocolBufferRollback(custom_schedule_service_proto.scheduled_getaways) as scheduled_getaways_msg:
                scheduled_getaways_msg.owner_id = owner_id
                scheduled_getaways_msg.schedule = schedule.get_proto_msg()
        current_zone_id = services.current_zone_id()
        if self._active_schedule and not self._active_schedule.is_getaway:
            custom_schedule_service_proto.current_schedule_zone_id = current_zone_id
            zone_data = services.get_persistence_service().get_zone_proto_buff(current_zone_id)
            zone_data.custom_schedule = self._active_schedule.get_proto_msg()
        elif self._current_schedule_zone_id:
            custom_schedule_service_proto.current_schedule_zone_id = self._current_schedule_zone_id
        custom_schedule_service_proto.mannequin_id = self.mannequin_id
        save_slot_data.gameplay_data.custom_schedule_service = custom_schedule_service_proto

    def initialize_zone_schedule(self) -> 'None':
        services.venue_service().on_venue_type_changed.register(self._sanitize_scheduled_getaways_for_zone)
        self._sanitize_scheduled_getaways_for_zone()
        getaway_travel_group = services.active_household().get_travel_group()
        if getaway_travel_group.group_type != TravelGroupData.GROUPTYPE_GETAWAY:
            getaway_travel_group = None
        if getaway_travel_group.uid in self._scheduled_getaways:
            self._active_getaway_schedule = self.get_planned_schedule(getaway_travel_group.uid)
            for sim_instance in services.active_household().instanced_sims_gen():
                self.start_player_facing_getaway_situation(sim_instance)
        venue_schedule = None
        zone_id = services.current_zone_id()
        venue_manager = services.get_instance_manager(sims4.resources.Types.VENUE)
        venue_tuning = venue_manager.get(build_buy.get_current_venue(zone_id))
        if getaway_travel_group is not None and getaway_travel_group is not None and services.active_household_id() == getaway_travel_group.get_getaway_household_id() and venue_tuning.is_custom_venue:
            schedule_data = self.get_schedule(None, zone_id)
            if schedule_data:
                venue_schedule = CustomSchedule(schedule_data)
        if getaway_travel_group and getaway_travel_group.zone_id == zone_id or venue_schedule is None:
            resolved_schedule = self._active_getaway_schedule
        else:
            getaway_travel_group = None
            resolved_schedule = venue_schedule
        if resolved_schedule is not None:
            self.set_active_schedule(resolved_schedule, travel_group=getaway_travel_group)
        else:
            self._active_schedule = None
        if self._current_schedule_zone_id:
            zone_data = services.get_persistence_service().get_zone_proto_buff(self._current_schedule_zone_id)
            schedule_proto = zone_data.custom_schedule if zone_data else None
            if schedule_proto.name != '':
                customScheduleData = CustomScheduleData.from_proto_msg(schedule_proto, clear_current_sim_ids=True)
                zone_data.custom_schedule = customScheduleData.to_proto_msg()
            self._current_schedule_zone_id = None

    def on_zone_unload(self) -> 'None':
        services.venue_service().on_venue_type_changed.unregister(self._sanitize_scheduled_getaways_for_zone)
        if self._active_schedule is None:
            return
        if self._active_schedule.is_getaway:
            return
        self.stop_active_schedule(startup_custom_venue_schedule=False)

    def suspend_schedule_behaviors_for_sim(self, sim_info:'SimInfo', situation:'Situation') -> 'None':
        if self._active_getaway_schedule is None or (situation.guid64 == CustomScheduleTuning.SCHEDULE_PLAYER_FACING_SITUATION.guid64 or (situation.guid64 == CustomScheduleTuning.SCHEDULE_SIMULATION_SITUATION.guid64 or situation.user_facing_type == SituationUserFacingType.PIVOTAL_MOMENT)) or situation.user_facing_type == SituationUserFacingType.HOLIDAY_EVENT:
            return
        self._active_getaway_schedule.suspend_functionality_for_sim(sim_info)
        if sim_info.sim_id in self._suspended_autonomy_sims:
            self._suspended_autonomy_sims[sim_info.sim_id].append(situation.situation_id)
        else:
            self._suspended_autonomy_sims[sim_info.sim_id] = [situation.situation_id]

    def restore_schedule_behaviors_for_sim(self, sim_instance:'Sim', situation_id:'int') -> 'None':
        if self._active_getaway_schedule is None:
            self._suspended_autonomy_sims = dict()
            return
        sim_id = sim_instance.sim_info.sim_id
        if sim_id not in self._suspended_autonomy_sims:
            return
        if situation_id in self._suspended_autonomy_sims[sim_id]:
            self._suspended_autonomy_sims[sim_id].remove(situation_id)
        if len(self._suspended_autonomy_sims[sim_id]) == 0:
            self._suspended_autonomy_sims.pop(sim_id, None)
            self._active_getaway_schedule.fixup_sim_for_timeslot(sim_instance)

    def _cancel_invalid_getaways(self, drama_node_uids:'List[int]', travel_group_uids:'List[int]') -> 'None':
        drama_scheduler_service = services.drama_scheduler_service()
        for uid in drama_node_uids:
            drama_scheduler_service.cancel_scheduled_node(uid)
            self.remove_scheduled_getaway(uid)
        travel_group_manager = services.travel_group_manager()
        active_household = services.active_household()
        active_household_travel_group = active_household.get_travel_group()
        for uid in travel_group_uids:
            travel_group = travel_group_manager.get(uid)
            if travel_group == active_household_travel_group:
                pass
            else:
                self.remove_scheduled_getaway(uid)
                travel_group_manager.destroy_travel_group_and_release_zone(travel_group)
        if active_household_travel_group is None:
            return
        if active_household_travel_group.uid in travel_group_uids:
            active_household_travel_group.end_vacation()

    def _sanitize_scheduled_getaways_for_zone(self):
        zone_id = services.current_zone_id()
        zone_data = services.get_persistence_service().get_zone_proto_buff(zone_id)
        venue_manager = services.get_instance_manager(sims4.resources.Types.VENUE)
        venue_tuning = venue_manager.get(build_buy.get_current_venue(zone_id))
        if venue_tuning in CustomScheduleTuning.SCHEDULE_PLAYER_FACING_SITUATION.compatible_venues:
            return
        travel_group_manager = services.travel_group_manager()
        drama_scheduler_service = services.drama_scheduler_service()
        affected_drama_nodes = []
        affected_travel_groups = []
        for (uid, schedule) in self._scheduled_getaways.items():
            scheduled_node = drama_scheduler_service.get_scheduled_node_by_uid(uid)
            if scheduled_node is not None and scheduled_node.get_situation_zone_id() == zone_id:
                affected_drama_nodes.append(uid)
            travel_group = travel_group_manager.get(uid)
            if travel_group is not None and travel_group.zone_id == zone_id:
                affected_travel_groups.append(uid)
        if affected_drama_nodes or not affected_travel_groups:
            return
        callback = lambda _: self._cancel_invalid_getaways(affected_drama_nodes, affected_travel_groups)
        sim_info = active_sim_info()
        dialog = CustomScheduleTuning.INCOMPATIBLE_VENUE_DIALOG(sim_info, resolver=SingleSimResolver(sim_info))
        dialog.show_dialog(on_response=callback, additional_tokens=(zone_data.name, venue_tuning.display_name))

    def start_player_facing_getaway_situation(self, sim_instance:'Sim') -> 'None':
        sim_info = sim_instance.sim_info
        if sim_info not in services.active_household() or sim_info.sim_id not in self.active_getaway_schedule.associated_sim_ids:
            return
        sim_instance = sim_info.get_sim_instance()
        situation_manager = services.get_zone_situation_manager()
        if situation_manager.get_situations_sim_is_in_by_type(sim_instance, CustomScheduleTuning.SCHEDULE_PLAYER_FACING_SITUATION):
            return
        guest_list = SituationGuestList(invite_only=True, host_sim_id=sim_info.id)
        guest_info = SituationGuestInfo(sim_info.id, CustomScheduleTuning.SCHEDULE_PLAYER_FACING_SITUATION.default_job(), RequestSpawningOption.CANNOT_SPAWN, BouncerRequestPriority.EVENT_VIP)
        guest_list.add_guest_info(guest_info)
        situation_manager = services.get_zone_situation_manager()
        situation_manager.create_situation(CustomScheduleTuning.SCHEDULE_PLAYER_FACING_SITUATION, guest_list=guest_list, spawn_sims_during_zone_spin_up=False, user_facing=True, zone_id=services.current_zone_id(), linked_sim_id=sim_info.sim_id)

    def stop_player_facing_getaway_situation(self, sim_info:'SimInfo') -> 'None':
        if self._active_getaway_schedule:
            self._active_getaway_schedule.stop_sim_player_facing_getaway_situation(sim_info)

    def on_build_buy_exit(self) -> 'None':
        if services.active_household() is None:
            return
        zone_id = services.current_zone_id()
        venue_manager = services.get_instance_manager(sims4.resources.Types.VENUE)
        venue_tuning = venue_manager.get(build_buy.get_current_venue(zone_id))
        if venue_tuning.is_custom_venue:
            if self._active_schedule:
                return
            schedule_data = self.get_schedule(None, services.current_zone_id())
            if schedule_data:
                self.set_active_schedule(CustomSchedule(schedule_data))
            return
        if self._active_schedule:
            if not self._active_schedule.is_getaway:
                self.stop_active_schedule(startup_custom_venue_schedule=False)
            else:
                self._active_getaway_schedule.getaway_travel_group.assign_beds()

    def on_zone_schedule_saved(self) -> 'None':
        if self._active_schedule and services.current_zone().is_in_build_buy and not self._active_schedule.is_getaway:
            self.stop_active_schedule(startup_custom_venue_schedule=False)

    def set_active_schedule(self, schedule:'CustomSchedule', travel_group:'Optional[TravelGroup]'=None) -> 'None':
        self._active_schedule = schedule
        if travel_group is not None:
            self._active_getaway_schedule = schedule
            if services.active_household_id() == travel_group.get_getaway_household_id() and travel_group.uid in self._scheduled_getaways:
                services.sim_spawner_service().register_sim_spawned_callback(self.start_player_facing_getaway_situation)
        self._active_schedule.start(travel_group)

    def get_static_commodity_list_for_sim(self, sim_info:'SimInfo') -> 'Optional[List[StaticCommodity]]':
        if self._active_schedule is None:
            return
        return self._active_schedule.get_static_commodity_list_for_sim(sim_info)

    def get_active_schedule(self) -> 'CustomSchedule':
        return self._active_schedule

    def stop_active_schedule(self, startup_custom_venue_schedule:'bool'=True, from_getaway_teardown=False) -> 'None':
        if from_getaway_teardown:
            situation_manager = services.get_zone_situation_manager()
            player_facing_situations = list(situation_manager.get_user_facing_situations_gen())
            for situation in player_facing_situations:
                if situation.situation_display_type == SituationDisplayType.GETAWAY:
                    situation_manager.destroy_situation_by_id(situation.id)
            services.sim_spawner_service().unregister_sim_spawned_callback(self.start_player_facing_getaway_situation)
            if self._active_getaway_schedule is not None:
                self._active_getaway_schedule.shutdown()
                if self._active_schedule == self._active_getaway_schedule:
                    self._active_schedule = None
                self._active_getaway_schedule = None
            else:
                logger.warn('No active getaway to shut down.')
        else:
            self._active_schedule.shutdown()
            self._active_schedule = None
        if startup_custom_venue_schedule:
            zone_id = services.current_zone_id()
            venue_manager = services.get_instance_manager(sims4.resources.Types.VENUE)
            venue_tuning = venue_manager.get(build_buy.get_current_venue(zone_id))
            if venue_tuning.is_custom_venue:
                zone_schedule_data = self.get_schedule(None, zone_id)
                if zone_schedule_data is not None:
                    self._active_schedule = CustomSchedule(zone_schedule_data)
                if self._active_schedule:
                    self._active_schedule.start()

    def create_custom_schedule(self, tuning_preset:'Optional[CustomSchedulePreset]'=None, protostring:'str'=None, is_getaway=False, track_challenge_override:'bool'=False) -> 'CustomSchedule':
        custom_schedule_data = None
        if tuning_preset is not None:
            custom_schedule_data = tuning_preset.create_data_class()
        elif protostring is not None:
            proto = CustomSchedule_pb2.CustomSchedule()
            text_format.Merge(protostring, proto)
            custom_schedule_data = CustomScheduleData.from_proto_msg(proto, track_challenge_override=track_challenge_override)
            custom_schedule_data.check_for_problems()
        custom_schedule = CustomSchedule(custom_schedule_data, is_getaway=is_getaway)
        return custom_schedule

    def add_custom_assignment_to_library(self, assignment:'ScheduleAssignmentData') -> 'None':
        self._custom_schedule_assignment_presets[assignment.display_name] = assignment

    def remove_from_custom_assignment_library(self, assignment_name:'str') -> 'Optional[str]':
        return self._custom_schedule_assignment_presets.pop(assignment_name, None)

    @property
    def custom_assignment_library(self) -> 'List[ScheduleAssignmentData]':
        return [assignment for assignment in self._custom_schedule_assignment_presets.values()]

    def get_assignment(self, assignment_name:'str', premade_name_hash:'Optional[str]'=None) -> 'Optional[ScheduleAssignmentData]':
        assignment = self._custom_schedule_assignment_presets.get(assignment_name, None)
        if assignment:
            return assignment
        return self._custom_schedule_assignment_presets.get(premade_name_hash, None)

    def add_custom_schedule_to_library(self, schedule:'CustomScheduleData') -> 'None':
        self._custom_schedule_presets[schedule.name] = schedule

    def remove_from_custom_schedule_library(self, schedule_name:'str') -> 'Optional[str]':
        return self._custom_schedule_presets.pop(schedule_name, None)

    @property
    def custom_schedule_library(self) -> 'List[CustomScheduleData]':
        return [schedule for schedule in self._custom_schedule_presets.values()]

    def get_schedule(self, schedule_name:'Optional[str]'=None, zone_id:'Optional[int]'=None, premade_name_hash:'Optional[str]'=None) -> 'Optional[CustomScheduleData]':
        if schedule_name is not None:
            custom_schedule = self._custom_schedule_presets.get(schedule_name, None)
            if custom_schedule:
                return custom_schedule
            if custom_schedule is None:
                return self._custom_schedule_presets.get(premade_name_hash, None)
        if zone_id:
            zone_data = services.get_persistence_service().get_zone_proto_buff(zone_id)
            try:
                schedule_proto = zone_data.custom_schedule if zone_data else None
                if schedule_proto and schedule_proto.name != '':
                    return CustomScheduleData.from_proto_msg(schedule_proto)
            except:
                pass

    def get_interaction_score_multiplier(self, interaction, sim:'Optional[Sim]'=DEFAULT) -> 'float':
        if self._active_schedule is None:
            return 1.0
        sim = interaction.sim if sim is DEFAULT else sim
        if self.is_sim_suspended(sim.sim_info):
            return 1.0
        return self._active_schedule.get_interaction_score_multiplier(interaction, sim)

    def schedule_getaway(self, schedule:'CustomSchedule', owner_id:'int') -> 'None':
        self._scheduled_getaways[owner_id] = schedule

    def migrate_scheduled_getaway(self, current_owner_id:'int', new_owner_id:'int') -> 'None':
        if current_owner_id in self._scheduled_getaways:
            self._scheduled_getaways[new_owner_id] = self._scheduled_getaways[current_owner_id]

    def remove_scheduled_getaway(self, owner_id:'int') -> 'None':
        self._scheduled_getaways.pop(owner_id, None)

    def get_planned_schedule(self, owner_id:'int') -> 'Optional[CustomSchedule]':
        return self._scheduled_getaways.get(owner_id, None)

    def update_planned_schedule(self, schedule:'CustomSchedule', owner_id:'int', is_active:'bool'=False, restart_schedule:'bool'=True) -> 'None':
        if owner_id in self._scheduled_getaways:
            sims_in_old_schedule = set(self._scheduled_getaways[owner_id].get_siminfos_active_in_time_slot())
            self._scheduled_getaways[owner_id] = schedule
            getaway_travel_group = services.travel_group_manager().get(owner_id)
            if is_active and (self._active_getaway_schedule is not None and restart_schedule) and getaway_travel_group is not None:
                self._active_getaway_schedule.shutdown(from_schedule_edit=True)
                schedule.background_situations = self._active_getaway_schedule.background_situations
                self.set_active_schedule(schedule, getaway_travel_group)
                sims_in_new_schedule = set(schedule.get_siminfos_active_in_time_slot())
                sims_to_kick_from_travel_group = sims_in_old_schedule.difference(sims_in_new_schedule)
                situation_manager = services.get_zone_situation_manager()
                for sim_info in sims_to_kick_from_travel_group:
                    schedule.getaway_travel_group.remove_sim_info(sim_info, blocklist_sim=False, skip_remove_from_schedule=True)
                    schedule.stop_sim_background_situation(sim_info)
                    kicked_sim_instance = sim_info.get_sim_instance(allow_hidden_flags=ALL_HIDDEN_REASONS_EXCEPT_UNINITIALIZED)
                    if kicked_sim_instance is None:
                        pass
                    else:
                        running_situations = situation_manager.get_situations_sim_is_in_by_type(kicked_sim_instance, CustomScheduleTuning.SCHEDULE_PLAYER_FACING_SITUATION)
                        if running_situations:
                            situation_manager.destroy_situation_by_id(running_situations[0].id)
                for sim_info in sims_in_new_schedule:
                    schedule.update_background_situation_job_title(sim_info)
                getaway_travel_group.assign_beds()
                self.send_all_situation_update_active_schedule()

    def send_all_situation_update_active_schedule(self) -> 'None':
        player_facing_situations = services.get_zone_situation_manager().get_situations_by_type(CustomScheduleTuning.SCHEDULE_PLAYER_FACING_SITUATION)
        for player_facing_situation in player_facing_situations:
            self.send_situation_update_active_schedule(player_facing_situation)

    def send_situation_update_active_schedule(self, situation:'GetawayPlayerFacingSituation') -> 'None':
        msg = Situations_pb2.SituationActiveScheduleUpdate()
        msg.situation_id = situation.id
        if self._active_schedule is not None:
            travel_group = services.active_household().get_travel_group()
            if travel_group is None:
                logger.error('There is no travel group for the active household.')
                return
            schedule = self.get_planned_schedule(travel_group.uid)
            if schedule is None:
                logger.error('The getaway schedule for the Travel Group does not exist.')
                return
            msg.custom_schedule = schedule.get_proto_msg()
        op = distributor.ops.SituationActiveScheduleUpdateOp(msg)
        Distributor.instance().add_op(situation, op)

    def initialize_situation_start_ui_msg_for_preset(self, msg:'Situations_pb2.SituationPrepare', initial_custom_schedule:'tuple', resolver:'Optional[Resolver]', actor_sim_id:'int', target_sim_id:'int') -> 'None':
        premade_custom_schedule = initial_custom_schedule.custom_schedule_preset
        data = premade_custom_schedule().create_data_class()
        situation_type = CustomScheduleTuning.SCHEDULE_PLAYER_FACING_SITUATION
        sim_info_manager = services.sim_info_manager()
        msg.ClearField('situation_resource_id')
        msg.situation_resource_id.append(situation_type.guid64)
        msg.situation_category = situation_type.category
        msg.is_new_from_tuning = True
        edit_data_msg = msg.edit_data
        edit_data_msg.duration_nights = initial_custom_schedule.duration
        lot_to_zone = dict()
        for neighborhood_proto in services.get_persistence_service().get_neighborhoods_proto_buf_gen():
            for lot_owner_info in neighborhood_proto.lots:
                lot_to_zone[lot_owner_info.lot_description_id] = lot_owner_info.zone_instance_id
        for (lot_desc_id, schedule) in CustomScheduleTuning.PREMADE_SCHEDULE_MAP.items():
            if schedule is premade_custom_schedule:
                edit_data_msg.zone_id = lot_to_zone[lot_desc_id]
                break
        if edit_data_msg.zone_id == 0:
            logger.error("Unable to determine zone id for schedule preset {}. Check that it's in CustomScheduleTuning.PREMADE_SCHEDULE_MAP and the lot is placed in the world.".format(initial_custom_schedule), owner='jmoline')
            edit_data_msg.zone_id = services.current_zone_id()
        associated_sim_ids = set()
        if data.assignment_presets:
            for (participant_type, premade_schedule_assignment) in initial_custom_schedule.auto_slot.items():
                preset_display_name_lockey = premade_schedule_assignment.display_name().hash
                if participant_type == ParticipantType.Actor and actor_sim_id != 0:
                    participants = [sim_info_manager.get(actor_sim_id)]
                elif participant_type == ParticipantType.TargetSim and target_sim_id != 0:
                    participants = [sim_info_manager.get(target_sim_id)]
                else:
                    participants = resolver.get_participants(participant_type)
                for assignment_preset in data.assignment_presets:
                    if assignment_preset.display_name_lockey == preset_display_name_lockey:
                        for participant in participants:
                            if not participant.is_sim:
                                logger.error('Unable to assign participant {} to schedule {} preset {}: Object {} is not a sim.', participant_type, str(premade_custom_schedule), str(premade_schedule_assignment), str(participant))
                            elif len(assignment_preset.sim_ids) >= assignment_preset.sim_count:
                                logger.error('Unable to assign participant {} sim {} to schedule {} preset {}: Assignment preset is already full.', participant_type, str(participant), str(premade_custom_schedule), str(premade_schedule_assignment))
                            elif participant.id in associated_sim_ids:
                                logger.error('Unable to assign participant {} sim {} to schedule {} preset {}: Sim already assigned to preset.', participant_type, str(participant), str(premade_custom_schedule), str(premade_schedule_assignment))
                            else:
                                assignment_preset.sim_ids.add(participant.id)
                                associated_sim_ids.add(participant.id)
                        break
                logger.error('Unable to assign participant {} ({}) to schedule {} preset {}: Schedule does not use requested assignment preset.', participant_type, str(participants), str(premade_custom_schedule), str(premade_schedule_assignment), owner='jmoline')
        elif initial_custom_schedule.auto_slot:
            logger.error('Unable to assign participants to schedule {}: Premade custom schedule has no assignment presets.', str(premade_custom_schedule), owner='jmoline')
        requested_schedule = CustomSchedule(data, is_getaway=True, associated_sim_ids=associated_sim_ids)
        requested_schedule.prepopulate_for_planner(keep_assigned_sims=True, attempt_to_fill_household_member=not initial_custom_schedule.auto_slot)
        edit_data_msg.getaway_schedule = requested_schedule.get_proto_msg()

    def exit_to_cas(self, age:'Age', gender:'Gender', msg:'str', connection) -> 'None':
        persistence_service = services.get_persistence_service()
        if persistence_service is None:
            return
        persistence_service.del_mannequin_proto_buff(self.mannequin_id)
        mannequin_proto = persistence_service.add_mannequin_proto_buff()
        if not msg:
            temp_sim_info = SimInfoBaseWrapper(sim_id=self.mannequin_id, age=age, gender=gender)
            if gender == Gender.MALE:
                resource = CustomScheduleTuning.DEFAULT_MANNEQUIN_DATA.male_adult
            if gender == Gender.FEMALE:
                resource = CustomScheduleTuning.DEFAULT_MANNEQUIN_DATA.female_adult
            if gender == Gender.MALE:
                resource = CustomScheduleTuning.DEFAULT_MANNEQUIN_DATA.male_child
            if gender == Gender.FEMALE:
                resource = CustomScheduleTuning.DEFAULT_MANNEQUIN_DATA.female_child
            if age != Age.CHILD and age != Age.CHILD and age == Age.CHILD and age == Age.CHILD and resource:
                temp_sim_info.load_from_resource(resource)
            mannequin_proto.mannequin_id = self.mannequin_id
            temp_sim_info.save_sim_info(mannequin_proto)
        else:
            text_format.Merge(msg, mannequin_proto)
            mannequin_proto.mannequin_id = self.mannequin_id
        current_zone_id = services.current_zone_id()
        mannequin_proto.zone_id = current_zone_id
        mannequin_proto.world_id = persistence_service.get_world_id_from_zone(current_zone_id)
        sims4.commands.client_cheat('sims.exit2caswithmannequinid {} club'.format(self.mannequin_id), connection)

    def send_mannequin_data(self) -> 'None':
        persistence_service = services.get_persistence_service()
        if persistence_service is None:
            return
        msg = CustomSchedule_pb2.CustomScheduleSetMannequinData()
        mannequin_proto = persistence_service.get_mannequin_proto_buff(self.mannequin_id)
        if mannequin_proto is None:
            return False
        msg.assignment_uniform = mannequin_proto
        Distributor.instance().add_op_with_no_owner(GenericProtocolBufferOp(Operation.CUSTOM_SCHEDULE_SET_CUSTOM_SET_MANNEQUIN_DATA, msg))

    def send_available_sims(self, criteria_data, sim_ids_to_include:'list[int]') -> 'None':
        available_sim_ids = set()
        active_household = services.active_household()
        invalid_sim_ids = []
        if active_household:
            household_sim_ids = set()
            invalid_sim_ids = []
            criterias = [ClubTunables.load_criteria_from_proto(data)[0] for data in criteria_data.criterias]
            criteria_filter_term = ClubCriteriaFilterTerm(minimum_filter_score=0, force_filter_term=True, criteria=criterias, for_custom_schedules=True)
            household_sim_ids.update(sim_info.sim_id for sim_info in active_household if not sim_info.is_baby)
            available_sim_ids.update(household_sim_ids)

            def is_sim_info_valid(sim_info):
                for criteria in criterias:
                    if not criteria is None:
                        if not criteria.required:
                            pass
                        elif not criteria.test_sim_info(sim_info):
                            return False
                return True

            sim_info_manager = services.sim_info_manager()
            for sim_id in sim_ids_to_include:
                sim_info = sim_info_manager.get(sim_id)
                if is_sim_info_valid(sim_info):
                    available_sim_ids.add(sim_id)

            def get_sim_filter_gsi_name():
                return 'CustomScheduleService: send_available_sims'

            sim_filter_service = services.sim_filter_service()

            def get_filter_results(sim_filter, sim_info):
                return sim_filter_service.submit_filter(sim_filter, None, blacklist_sim_ids=available_sim_ids, requesting_sim_info=sim_info, allow_yielding=False, include_rabbithole_sims=True, gsi_source_fn=get_sim_filter_gsi_name)

            in_build_buy = services.current_zone().is_in_build_buy
            if CustomScheduleTuning.SIM_PICKER.known_filter:
                if in_build_buy:
                    known_filter = CustomScheduleTuning.SIM_PICKER.known_filter(filter_terms=(criteria_filter_term,))
                else:
                    known_filter = CustomScheduleTuning.SIM_PICKER.known_filter()
                for requesting_sim_info in active_household:
                    filter_results = get_filter_results(known_filter, requesting_sim_info)
                    for result in filter_results:
                        available_sim_ids.add(result.sim_info.sim_id)
                        if in_build_buy or not is_sim_info_valid(result.sim_info):
                            invalid_sim_ids.append(result.sim_info.sim_id)
            if CustomScheduleTuning.SIM_PICKER.unknown_filter:
                filter_terms_to_iterate = [(criteria_filter_term,)]
                if not in_build_buy:
                    filter_terms_to_iterate.append(())
                for filter_term in filter_terms_to_iterate:
                    needed_sims = CustomScheduleTuning.SIM_PICKER.target_count - len(available_sim_ids) + len(household_sim_ids)
                    if filter_term:
                        needed_sims += len(invalid_sim_ids)
                    if needed_sims <= 0:
                        break
                    unknown_filter = CustomScheduleTuning.SIM_PICKER.unknown_filter(filter_terms=filter_term)
                    filter_results = get_filter_results(unknown_filter, services.active_sim_info())
                    if filter_results:
                        random.shuffle(filter_results)
                        filter_results.sort(reverse=True, key=lambda result: result.score)
                        safe_range = min([needed_sims, len(filter_results)])
                        for i in range(safe_range):
                            available_sim_ids.add(filter_results[i].sim_info.sim_id)
                            if not filter_term:
                                invalid_sim_ids.append(filter_results[i].sim_info.sim_id)
            if in_build_buy:
                available_sim_ids.difference_update(household_sim_ids)
            else:
                invalid_sim_ids.extend(sim_info.sim_id for sim_info in active_household if not is_sim_info_valid(sim_info))
        msg = CustomSchedule_pb2.CustomScheduleSetAvailableSims()
        msg.sim_ids.extend(available_sim_ids)
        msg.invalid_sim_ids.extend(invalid_sim_ids)
        Distributor.instance().add_op_with_no_owner(GenericProtocolBufferOp(Operation.CUSTOM_SCHEDULE_SET_AVAILABLE_SIMS, msg))
