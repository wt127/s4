import servicesfrom event_testing.test_base import BaseTestfrom event_testing.results import TestResultfrom interactions import ParticipantTypefrom sims4.tuning.tunable import HasTunableSingletonFactory, AutoFactoryInit
class GetawayIsAffordanceEncouragedTest(HasTunableSingletonFactory, AutoFactoryInit, BaseTest):
    FACTORY_TUNABLES = {}

    def get_expected_args(self):
        return {'subjects': ParticipantType.Actor, 'affordance': ParticipantType.Affordance}

    def __call__(self, subjects=(), affordance=None) -> TestResult:
        subject = next(iter(subjects), None)
        if subject is None:
            return TestResult(False, 'Subject not found for getaway encouragement test.', tooltip=self.tooltip)
        if affordance is None:
            return TestResult(False, 'No affordance to test.', tooltip=self.tooltip)
        custom_schedule_service = services.custom_schedule_service()
        if custom_schedule_service is None:
            return TestResult(False, 'Custom schedule service is inactive.', tooltip=self.tooltip)
        schedule = custom_schedule_service.get_active_schedule()
        if schedule is None:
            return TestResult(False, 'No schedule is active.', tooltip=self.tooltip)
        if not schedule.get_sim_assignment_from_time_slot(subject.id):
            return TestResult(False, 'Subject not participating in active schedule.', tooltip=self.tooltip)
        affordance_set = set(affordance.affordances)
        if all(not affordance_set.intersection(affordance_list) for affordance_list in schedule.get_sim_assignment_affordances_gen(subject.id)):
            return TestResult(False, "Affordance not in assignment's list of affordances.", tooltip=self.tooltip)
        return TestResult.TRUE
