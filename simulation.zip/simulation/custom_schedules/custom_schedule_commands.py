import clockimport servicesimport sims4import telemetry_helperfrom custom_schedules.custom_schedule import CustomSchedulefrom custom_schedules.custom_schedule_data_classes import CustomScheduleData, ScheduleAssignmentDatafrom custom_schedules.custom_schedule_tuning import CustomScheduleTuningfrom date_and_time import DateAndTimefrom drama_scheduler.drama_node_types import DramaNodeTypefrom protocolbuffers.DistributorOps_pb2 import Operationfrom clubs.club_tuning import ClubTunablesfrom distributor.ops import GenericProtocolBufferOpfrom distributor.rollback import ProtocolBufferRollbackfrom distributor.system import Distributorfrom google.protobuf import text_formatfrom protocolbuffers import CustomSchedule_pb2, Clubs_pb2, Situations_pb2, FileSerialization_pb2from server_commands.argument_helpers import TunableInstanceParam, get_optional_target, OptionalSimInfoParamfrom sims.sim_info_base_wrapper import SimInfoBaseWrapperfrom sims.sim_info_types import Age, Genderfrom sims4.commands import Command, CommandType, Outputfrom sims4.resources import Typesfrom situations.bouncer.bouncer_types import RequestSpawningOption, BouncerRequestPriorityfrom situations.situation_guest_list import SituationGuestList, SituationGuestInfoimport id_generatorimport sims4.commandsfrom travel_group.travel_group_getaway import TravelGroupGetawaylogger = sims4.log.Logger('CustomScheduleCommands', default_owner='nabaker')
@Command('custom_schedule.get_schedule', command_type=CommandType.Live)
def get_schedule(zone_id:int, name:str=None, premade_name_hash:str=None, _connection=None):
    msg = CustomSchedule_pb2.CustomScheduleSetCustomSchedule()
    try:
        custom_schedule_service = services.custom_schedule_service()
        requested_schedule_data = custom_schedule_service.get_schedule(name, zone_id, premade_name_hash)
        if requested_schedule_data is not None:
            requested_schedule_data_copy = CustomScheduleData.from_proto_msg(requested_schedule_data.to_proto_msg())
            if services.current_zone().is_in_build_buy:
                requested_schedule_data_copy.fill_proto_msg(msg.schedule, validate_sims=True)
            else:
                requested_schedule = CustomSchedule(requested_schedule_data_copy, is_getaway=True)
                requested_schedule.prepopulate_for_planner()
                msg.schedule = requested_schedule.get_proto_msg()
    except Exception as e:
        logger.error('Exception encountered for custom_schedule.get_schedule({}, {}, {}): {}', zone_id, name, premade_name_hash, e)
    distributor = Distributor.instance()
    distributor.add_op_with_no_owner(GenericProtocolBufferOp(Operation.CUSTOM_SCHEDULE_SET_CUSTOM_SCHEDULE, msg))

@Command('custom_schedule.get_assignment', command_type=CommandType.Live)
def get_assignment(name:str, premade_name_hash:str=None, _connection=None):
    custom_schedule_service = services.custom_schedule_service()
    msg = CustomSchedule_pb2.CustomScheduleSetCustomAssignment()
    try:
        requested_assignment = custom_schedule_service.get_assignment(name, premade_name_hash)
        if requested_assignment is None:
            logger.error('No assignment found with that name ({}, {}).', name, premade_name_hash)
        else:
            requested_assignment.fill_proto_msg(msg.assignment, validate_sims=True)
    except Exception as e:
        logger.error('Exception encountered for custom_schedule.get_assignment({}, {}): {}', name, premade_name_hash, e)
    distributor = Distributor.instance()
    distributor.add_op_with_no_owner(GenericProtocolBufferOp(Operation.CUSTOM_SCHEDULE_SET_CUSTOM_ASSIGNMENT, msg))

@Command('custom_schedule.get_schedule_library', command_type=CommandType.Live)
def get_schedule_library(zone_id:int=0, _connection=None):
    msg = CustomSchedule_pb2.CustomScheduleSetScheduleList()
    custom_schedule_service = services.custom_schedule_service()
    for schedule_data in custom_schedule_service.custom_schedule_library:
        with ProtocolBufferRollback(msg.schedule_list.schedules) as schedule_msg:
            schedule_msg.name = schedule_data.name
            schedule_msg.is_immutable = schedule_data.is_immutable
            schedule_msg.lot_current = False
            schedule_msg.has_rules = bool(schedule_data.preselected_getaway_challenges)
            if schedule_data.display_name_lockey is not None:
                schedule_msg.premade_name.hash = schedule_data.display_name_lockey
    distributor = Distributor.instance()
    distributor.add_op_with_no_owner(GenericProtocolBufferOp(Operation.CUSTOM_SCHEDULE_SET_CUSTOM_SET_SCHEDULE_LIST, msg))

@Command('custom_schedule.get_assignment_library', command_type=CommandType.Live)
def get_assignment_library(_connection=None):
    msg = CustomSchedule_pb2.CustomScheduleSetAssignmentList()
    custom_schedule_service = services.custom_schedule_service()
    for assignment_data in custom_schedule_service.custom_assignment_library:
        with ProtocolBufferRollback(msg.assignment_list.assignments) as assignment_msg:
            assignment_msg.name = assignment_data.display_name
            assignment_msg.is_immutable = assignment_data.is_immutable
            if assignment_data.display_name_lockey is not None:
                assignment_msg.premade_name.hash = assignment_data.display_name_lockey
    distributor = Distributor.instance()
    distributor.add_op_with_no_owner(GenericProtocolBufferOp(Operation.CUSTOM_SCHEDULE_SET_CUSTOM_SET_ASSIGNMENT_LIST, msg))

@Command('custom_schedule.save_assignment_to_library', command_type=CommandType.Live)
def save_assignment_to_library(msg:str, _connection=None):
    proto = CustomSchedule_pb2.ScheduleAssignment()
    text_format.Merge(msg, proto)
    assignment = ScheduleAssignmentData.from_proto_msg(proto, force_mutable=True)
    custom_schedule_service = services.custom_schedule_service()
    custom_schedule_service.add_custom_assignment_to_library(assignment)

@Command('custom_schedule.save_schedule', command_type=CommandType.Live)
def save_schedule(is_library:bool, msg:str, _connection=None):
    proto = CustomSchedule_pb2.CustomSchedule()
    text_format.Merge(msg, proto)
    if is_library:
        schedule = CustomScheduleData.from_proto_msg(proto, clear_current_sim_ids=True, force_mutable=True)
        custom_schedule_service = services.custom_schedule_service()
        custom_schedule_service.add_custom_schedule_to_library(schedule)
    else:
        zone_data = services.get_persistence_service().get_zone_proto_buff(services.current_zone_id())
        if zone_data is not None:
            zone_data.custom_schedule = proto
            custom_schedule_service = services.custom_schedule_service()
            custom_schedule_service.on_zone_schedule_saved()

@Command('custom_schedule.delete_schedule', command_type=CommandType.Live)
def delete_schedule(name:str, _connection=None):
    custom_schedule_service = services.custom_schedule_service()
    custom_schedule_service.remove_from_custom_schedule_library(name)

@Command('custom_schedule.delete_assignment', command_type=CommandType.Live)
def delete_assignment(name:str, _connection=None):
    custom_schedule_service = services.custom_schedule_service()
    custom_schedule_service.remove_from_custom_assignment_library(name)

@Command('custom_schedule.exit_to_cas', command_type=CommandType.Live)
def exit_to_cas(age:int, gender:int, msg:str, _connection=None):
    custom_schedule_service = services.custom_schedule_service()
    custom_schedule_service.exit_to_cas(age, gender, msg, _connection)

@Command('custom_schedule.get_mannequin_data', command_type=CommandType.Live)
def get_mannequin_data(_connection=None):
    custom_schedule_service = services.custom_schedule_service()
    custom_schedule_service.send_mannequin_data()

@Command('custom_schedule.get_available_sims', command_type=CommandType.Live)
def get_available_sims(criteria_data:str, *sim_ids, _connection=None):
    custom_schedule_service = services.custom_schedule_service()
    proto = Clubs_pb2.ClubBuildingInfo()
    text_format.Merge(criteria_data, proto)
    custom_schedule_service.send_available_sims(proto, sim_ids)

@Command('custom_schedule.schedule_tuning_preset', command_type=CommandType.DebugOnly)
def schedule_tuning_preset(preset:TunableInstanceParam(Types.SNIPPET), duration:int, days_from_now:int=0, zone_id:int=0, *sim_ids_to_include, _connection=None):
    output = Output(_connection)
    custom_schedule_service = services.custom_schedule_service()
    schedule = custom_schedule_service.create_custom_schedule(preset(), is_getaway=True)
    sim_now = services.time_service().sim_now
    scheduled_time = sim_now
    if days_from_now != 0:
        first_time_slot_hour = schedule.get_first_time_slot_time_of_day().in_hours()
        start_time = sim_now + clock.time_until_hour_of_day(sim_now, first_time_slot_hour)
        days_from_now = days_from_now if sim_now.hour() < first_time_slot_hour else days_from_now - 1
        scheduled_time = start_time + clock.interval_in_sim_days(days_from_now)
    zone_id = zone_id or services.current_zone_id()
    sim_override_index = 0
    guest_list = None
    for (assignment_id, sim_id) in zip(sim_ids_to_include[0::2], sim_ids_to_include[1::2]):
        if sim_override_index == 0:
            guest_list = SituationGuestList(invite_only=True, host_sim_id=sim_id)
        else:
            guest_list.add_guest_info(SituationGuestInfo(sim_id, CustomScheduleTuning.SCHEDULE_PLAYER_FACING_SITUATION.default_job(), RequestSpawningOption.CANNOT_SPAWN, BouncerRequestPriority.EVENT_VIP, expectation_preference=True))
        schedule.insert_sim_id_into_override(assignment_id, sim_id, output)
        sim_override_index += 1
    schedule.prepopulate_for_planner()
    guest_sim_ids = [guest_info.sim_id for guest_info in guest_list.guest_info_gen()]
    guest_sim_ids.append(guest_list.host_sim_id)
    drama_node_schedule_kwargs = {'zone_id': zone_id, 'household_id': guest_list.host_sim_info.household_id, 'duration': duration, 'guest_sim_ids': guest_sim_ids, 'host_sim_id': guest_list.host_sim_info.id, 'lot_value': 0, 'schedule': schedule}
    situation_id = services.get_zone_situation_manager().create_situation(CustomScheduleTuning.SCHEDULE_PLAYER_FACING_SITUATION, guest_list=guest_list, zone_id=zone_id, scoring_enabled=False, scheduled_time=scheduled_time, drama_node_kwargs=drama_node_schedule_kwargs)
    output = Output(_connection)
    if situation_id is None:
        output('Failed to schedule the Getaway.')
        return
    if situation_id is not None and days_from_now == 0:
        output('Successfully created situation: {}.'.format(situation_id))
    elif situation_id is not None:
        output('Successfully scheduled situation for the future: {}.'.format(situation_id))

@Command('custom_schedule.start_tuning_preset', command_type=CommandType.DebugOnly)
def start_tuning_preset(preset:TunableInstanceParam(Types.SNIPPET), _connection=None):
    custom_schedule_service = services.custom_schedule_service()
    custom_schedule = custom_schedule_service.create_custom_schedule(preset())
    custom_schedule_service.set_active_schedule(custom_schedule)

@Command('custom_schedule.shutdown_active_schedule', command_type=CommandType.DebugOnly)
def shutdown_active_schedule(_connection=None):
    custom_schedule_service = services.custom_schedule_service()
    custom_schedule = custom_schedule_service.get_active_schedule()
    custom_schedule.shutdown()

@Command('custom_schedule.get_assignment_from_sim', command_type=CommandType.DebugOnly)
def get_assignment_from_sim(sim_id:int, _connection=None):
    custom_schedule_service = services.custom_schedule_service()
    schedule = custom_schedule_service.get_active_schedule()
    time_slot_assignment = schedule.get_sim_assignment_from_time_slot(sim_id)
    output = Output(_connection)
    output('{}'.format(time_slot_assignment.assignment_overrides.display_name))

@Command('custom_schedule.get_sims_in_each_assignment', command_type=CommandType.DebugOnly)
def get_sims_in_each_assignment(_connection=None):
    custom_schedule_service = services.custom_schedule_service()
    schedule = custom_schedule_service.active_schedule
    output = Output(_connection)
    if schedule is None:
        output('No active schedule!')
        return
    for assignment in schedule._active_time_slot.scheduled_assignments:
        output_string = f'{assignment.assignment_overrides.display_name} - {assignment.assignment_overrides.sim_ids}'
        output(output_string)
TELEMETRY_GROUP_GETAWAY = 'GAWY'TELEMETRY_FIELD_GETAWAY_SAVE = 'SAVE'TELEMETRY_FIELD_GETAWAY_RULES = 'type'TELEMETRY_FIELD_GETAWAY_ACTIVITIES = 'actv'TELEMETRY_FIELD_GETAWAY_ID = 'gtid'writer = sims4.telemetry.TelemetryWriter(TELEMETRY_GROUP_GETAWAY)
@Command('custom_schedule.create_getaway_situation', command_type=CommandType.Live)
def create_getaway_situation(zone_id:int, duration:int, scheduled_time:int=0, drama_node_uid:int=0, schedule_proto_string:str=None, lot_value:int=0, recurring_days:str=None, end_time:int=0, use_current_track_values:bool=False, _connection=None):
    situation_manager = services.get_zone_situation_manager()
    scheduled_time_day_time = DateAndTime(scheduled_time) if scheduled_time != 0 else services.time_service().sim_now
    drama_node = drama_node_uid if drama_node_uid else None
    zone_id = zone_id or services.current_zone_id()
    active_sim_info = services.active_sim_info()
    if active_sim_info is None:
        logger.error("Can't schedule or edit a getaway due to missing an active sim.", owner='jmoline')
        return
    schedule = None
    custom_schedule_service = services.custom_schedule_service()
    if schedule_proto_string is not None:
        schedule = custom_schedule_service.create_custom_schedule(protostring=schedule_proto_string, track_challenge_override=use_current_track_values)
    if drama_node is not None:
        travel_group = services.travel_group_manager().get(drama_node)
        if travel_group is not None:
            if schedule is not None and travel_group.group_type == FileSerialization_pb2.TravelGroupData.GROUPTYPE_GETAWAY:
                custom_schedule_service.update_planned_schedule(schedule, travel_group.uid, True)
            return
    if recurring_days:
        recurring_day_tokens = recurring_days.split(',')
    else:
        recurring_day_tokens = ()
    situation_type = CustomScheduleTuning.SCHEDULE_PLAYER_FACING_SITUATION
    guest_list = SituationGuestList(True, active_sim_info.id)
    drama_node_schedule_kwargs = {'zone_id': zone_id, 'household_id': active_sim_info.household_id, 'duration': duration, 'guest_sim_ids': [guest_sim_info.id for guest_sim_info in schedule.get_siminfos_active_at_time(scheduled_time_day_time)], 'host_sim_id': active_sim_info.id, 'lot_value': lot_value, 'schedule': schedule, 'start_time': scheduled_time_day_time, 'end_time': DateAndTime(end_time), 'recurring_days': tuple([int(num.strip()) for num in recurring_day_tokens])}
    situation_id = situation_manager.create_situation(situation_type, guest_list=guest_list, zone_id=zone_id, scoring_enabled=False, scheduled_time=scheduled_time_day_time, existing_drama_node_uid=drama_node, drama_node_kwargs=drama_node_schedule_kwargs)
    if schedule is not None:
        if situation_id is not None and scheduled_time == 0:
            sims4.commands.output('Successfully created situation: {}.'.format(situation_id), _connection)
            sims4.commands.automation_output('SituationCreateGL; Status:Success, Id:{}'.format(situation_id), _connection)
        elif situation_id is not None:
            sims4.commands.output('Successfully scheduled situation for the future: {}.'.format(situation_id), _connection)
            sims4.commands.automation_output('SituationCreateGL; Status:Success, Id:{}'.format(situation_id), _connection)
        rules_set = set()
        activities_set = set()
        for getaway_challenge in schedule.getaway_challenges:
            rules_set.add(str(getaway_challenge.guid64))
        for time_slot in schedule.time_slots:
            if time_slot.fallback_behavior is not None:
                activities_set.add(str(time_slot.fallback_behavior.guid64))
        activities = ','.join(activities_set)
        rules = ','.join(rules_set)
        with telemetry_helper.begin_hook(writer, TELEMETRY_FIELD_GETAWAY_SAVE) as hook:
            hook.write_string(TELEMETRY_FIELD_GETAWAY_RULES, rules)
            hook.write_string(TELEMETRY_FIELD_GETAWAY_ACTIVITIES, activities)
            hook.write_int(TELEMETRY_FIELD_GETAWAY_ID, situation_id)
    else:
        sims4.commands.output('Insufficient funds to create situation', _connection)
        sims4.commands.automation_output('SituationCreateGL; Status:Failed, Message: Insufficient funds to create situation', _connection)
    return True

def resolve_sim_and_drama_node(opt_sim, reference_uid, _connection):
    sim = get_optional_target(opt_sim, _connection, target_type=OptionalSimInfoParam)
    if sim is None:
        sims4.commands.output('Invalid sim: {} provided.'.format(opt_sim), _connection)
        return (None, None, None)
    drama_scheduler = services.drama_scheduler_service()
    affected_drama_node = None
    active_travel_group = None
    travel_group = sim.travel_group if sim else None
    household = sim.household if sim else None
    if household is not None:
        travel_group = household.get_travel_group()
    if travel_group is None and reference_uid == -1:
        active_travel_group = travel_group
    else:
        affected_drama_node = drama_scheduler.get_scheduled_node_by_uid(reference_uid)
        if travel_group.uid == reference_uid:
            active_travel_group = travel_group
    if affected_drama_node is None and active_travel_group is None:
        if reference_uid == -1:
            sims4.commands.output('Active getaway drama node not found.', _connection)
        else:
            sims4.commands.output('Invalid getaway id: {} provided.'.format(reference_uid), _connection)
        return (None, None, None)
    if affected_drama_node is not None and affected_drama_node.drama_node_type != DramaNodeType.GETAWAY:
        sims4.commands.output('Non getaway drama node id: {} provided.'.format(reference_uid), _connection)
        return (None, None, None)
    if active_travel_group is not None and active_travel_group.group_type != FileSerialization_pb2.TravelGroupData.GROUPTYPE_GETAWAY:
        sims4.commands.output('Non getaway travel group id: {} provided.'.format(reference_uid), _connection)
        return (None, None, None)
    return (sim, affected_drama_node, active_travel_group)

@Command('custom_schedule.edit_getaway', command_type=CommandType.Live)
def edit_getaway(opt_sim:OptionalSimInfoParam=None, reference_uid:int=-1, _connection=None) -> None:
    (sim, affected_drama_node, active_travel_group) = resolve_sim_and_drama_node(opt_sim, reference_uid, _connection)
    if sim is None:
        return
    situation_manager = services.get_zone_situation_manager()
    if affected_drama_node is not None:
        situation_manager.send_situation_start_ui_for_edit(sim, drama_node_uid=affected_drama_node.uid)
    elif active_travel_group is not None:
        situation_manager.send_situation_start_ui_for_edit(sim, travel_group_uid=active_travel_group.uid)

@sims4.commands.Command('custom_schedule.cancel_getaway', command_type=CommandType.Live)
def cancel_getaway(opt_sim:OptionalSimInfoParam=None, reference_uid:int=-1, _connection=None) -> None:
    (sim, affected_drama_node, active_travel_group) = resolve_sim_and_drama_node(opt_sim, reference_uid, _connection)
    if sim is None:
        return
    if affected_drama_node is not None:
        drama_scheduler = services.drama_scheduler_service()
        drama_scheduler.cancel_scheduled_node(affected_drama_node.uid)
    elif active_travel_group is not None:
        active_travel_group.end_vacation()

@sims4.commands.Command('custom_schedule.get_getaway_rules', command_type=CommandType.Live)
def get_getaway_rules(situation_type:TunableInstanceParam(sims4.resources.Types.SITUATION)=None, _connection=None):
    situation_getaway_rules_msg = Situations_pb2.SituationGetawayRules()
    manager = services.get_instance_manager(Types.GETAWAY_CHALLENGE)
    for challenge in manager.types.values():
        with ProtocolBufferRollback(situation_getaway_rules_msg.options) as option_msg:
            option_msg.rule_guid64 = challenge.guid64
            option_msg.display_name = challenge.display_name()
            option_msg.description = challenge.description_tooltip()
            option_msg.icon.type = challenge.icon.type
            option_msg.icon.group = challenge.icon.group
            option_msg.icon.instance = challenge.icon.instance
            for group in challenge.groups:
                with ProtocolBufferRollback(option_msg.groups) as group_msg:
                    group_msg.category_id = len(option_msg.groups)
                    group_msg.category_display_name = group.group_name()
                    group_msg.is_multi_select = group.multi_select
                    group_msg.disallowed_ages.extend(group.disallowed_ages)
                    try:
                        group_msg.disallowed_species.extend(group.disallowed_species)
                    except:
                        pass
            option_msg.is_track_based_challenge = challenge.is_elimination_challenge
    op = GenericProtocolBufferOp(Operation.MSG_SITUATION_GETAWAY_RULES, situation_getaway_rules_msg)
    Distributor.instance().add_op_with_no_owner(op)

@sims4.commands.Command('getaway_reward.show_progress', command_type=CommandType.DebugOnly)
def show_reward_progress(_connection=None):
    travel_group = services.active_household().get_travel_group()
    if travel_group is None:
        sims4.commands.output('No travel group for active household.', _connection)
    sim_info_manager = services.sim_info_manager()
    reward_trait_progress = travel_group.reward_trait_progress
    for category in reward_trait_progress:
        sims4.commands.output('Category: {}'.format(category), _connection)
        for sim_id in reward_trait_progress[category]:
            sim = sim_info_manager.get(sim_id)
            sims4.commands.output('Sim {}: {}'.format(sim, sum(reward_trait_progress[category][sim_id])), _connection)
    rule_reward_progress = travel_group.rule_hour_progression
    challenge_manager = services.get_instance_manager(sims4.resources.Types.GETAWAY_CHALLENGE)
    for rule_guid64 in rule_reward_progress:
        challenge = challenge_manager.get(rule_guid64)
        sims4.commands.output('Rule: {}'.format(challenge), _connection)
        for sim_id in rule_reward_progress[rule_guid64]:
            sim = sim_info_manager.get(sim_id)
            sims4.commands.output('Sim {}: {}'.format(sim, rule_reward_progress[rule_guid64][sim_id]), _connection)
