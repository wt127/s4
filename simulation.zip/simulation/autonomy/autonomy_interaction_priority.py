from sims4.tuning.dynamic_enum import DynamicEnum
class AutonomyInteractionPriority(DynamicEnum):
    INVALID = 0
