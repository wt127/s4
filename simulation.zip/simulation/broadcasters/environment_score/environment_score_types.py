import enum
class EnvironmentScoreType(enum.Int):
    MOOD_SCORING = 1
    NEGATIVE_SCORING = 2
    POSITIVE_SCORING = 3
