import enum
class BuffDisplayType(enum.Int, export=False):
    DEFAULT = 0
    BURNOUT = 1
