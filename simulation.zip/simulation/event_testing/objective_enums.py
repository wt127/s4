from sims4.tuning.dynamic_enum import DynamicEnum
class ObjectiveCategoryType(DynamicEnum):
    NO_CATEGORY_TYPE = 0
