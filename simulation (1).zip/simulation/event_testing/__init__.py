import enum
class TargetIdTypes(enum.Int):
    DEFAULT = 0
    INSTANCE = 1
    DEFINITION = 2
    HOUSEHOLD = 3
    PICKED_ITEM_ID = 4
