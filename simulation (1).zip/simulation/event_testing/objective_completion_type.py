import enum
class ObjectiveCompletionType(enum.Int, export=False):
    OBJECTIVE_COMPLETE = 0
    MILESTONE_COMPLETE = 1
