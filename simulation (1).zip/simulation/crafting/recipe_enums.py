from sims4.tuning.dynamic_enum import DynamicEnumimport enum
class RecipeDifficulty(DynamicEnum):
    NORMAL = 0
