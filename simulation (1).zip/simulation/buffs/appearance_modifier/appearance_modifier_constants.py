
class AppearanceModifierDynamicAttachmentID:
    DYNAMIC_ATTACHMENT_FAIRY_WINGS = 455208
