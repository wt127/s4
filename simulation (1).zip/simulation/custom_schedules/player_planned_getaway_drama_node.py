from __future__ import annotationsfrom custom_schedules.recurring_getaway import RecurringGetawayMixinfrom date_and_time import DateAndTimefrom distributor.shared_messages import IconInfoData, build_icon_info_msgfrom drama_scheduler.drama_enums import DramaNodeRunOutcomefrom protocolbuffers import UI_pb2, Dialog_pb2from sims4.localization import LocalizationHelperTuning, TunableLocalizedStringFactoryfrom tunable_time import TunableTimeSpanfrom typing import TYPE_CHECKING, Optional, Tuplefrom ui.ui_dialog import UiDialogResponse, ButtonTypefrom world.travel_service import travel_sims_to_zoneif TYPE_CHECKING:
    from ui.ui_dialog import UiDialogOkCancel
    from protocolbuffers.GameplaySaveData_pb2 import PersistableDramaNode
    from sims4 import PropertyStreamWriter, PropertyStreamReader
    from custom_schedules.custom_schedule import CustomSchedule
    from event_testing.resolver import Resolver
    from typing import Iterable, Iterator, List
    from sims.sim_info import SimInfo
    from situations.situation import Situation
    from situations.situation_job import SituationJob
    from situations.situation_guest_list import SituationGuestInfoimport clockimport servicesfrom custom_schedules.custom_schedule_tuning import CustomScheduleTuningfrom date_and_time import TimeSpanfrom drama_scheduler.drama_node_types import DramaNodeTypefrom drama_scheduler.player_planned_stayover_drama_node import PlayerPlannedStayoverDramaNodefrom event_testing.results import TestResultfrom sims4 import logfrom sims4.tuning.tunable import Tunable, TunableRangefrom sims4.utils import classproperty, flexmethodlogger = log.Logger('PlayerPlannedGetawayDramaNode', default_owner='cparrish')INITIATOR_ID_TOKEN = 'initiator_id'LOT_VALUE_TOKEN = 'lot_value'START_TIME_TOKEN = 'start_time'END_TIME_TOKEN = 'end_time'RECURRING_DAYS_TOKEN = 'recurring_days'
class PlayerPlannedGetawayDramaNode(RecurringGetawayMixin, PlayerPlannedStayoverDramaNode):
    RESPONSE_ID_START_WITHOUT_ME = 1
    INSTANCE_TUNABLES = {'cost_multiplier': TunableRange(description='\n            This multiplier is applied to the lot value of the location of the getaway to determine the cost\n            of attendance.\n            ', tunable_type=float, default=0.1, minimum=0.0), 'start_without_me_text': TunableLocalizedStringFactory(description='\n            Button text for starting the Getaway while the sim is off-lot of the Getaway.\n            '), 'default_duration_nights': Tunable(description='\n            The default number of nights to select for Getaway duration.\n            ', tunable_type=int, default=2), 'maximum_duration_nights': Tunable(description='\n            The maximum number of selectable nights for Getaway duration.\n            ', tunable_type=int, default=6), 'advance_notice_time': TunableTimeSpan(description='\n            The amount of time between the alert and the start of the getaway.\n            ', default_hours=1, locked_args={'days': 0, 'minutes': 0})}

    def __init__(self, *args, schedule:'CustomSchedule'=None, host_sim_id:'Optional[int]'=None, lot_value:'Optional[int]'=None, recurring_days:'Tuple[int, ...]'=(), start_time:'int'=0, end_time:'int'=0, **kwargs) -> 'None':
        super().__init__(*args, **kwargs)
        self._host_sim_id = host_sim_id
        self._lot_value = lot_value
        self._allow_no_household = True
        self._schedule = schedule
        self._recurring_days = recurring_days
        self._start_time = DateAndTime(start_time)
        self._end_time = DateAndTime(end_time)

    def schedule(self, resolver:'Resolver', specific_time:'DateAndTime'=None, time_modifier:'TimeSpan'=TimeSpan.ZERO, **setup_kwargs) -> 'TestResult':
        if self._schedule is None:
            return TestResult(False, 'CustomSchedule not available.')
        custom_schedule_service = services.custom_schedule_service()
        if custom_schedule_service is None:
            return TestResult(False, "Can't schedule getaway because CustomScheduleService is unavailable.")
        success = super().schedule(resolver, specific_time=specific_time, time_modifier=time_modifier, **setup_kwargs)
        if not success:
            return success
        custom_schedule_service.schedule_getaway(self._schedule, self.uid)
        return TestResult.TRUE

    def cleanup(self, from_service_stop:'bool'=False) -> 'None':
        if not from_service_stop:
            custom_schedule_service = services.custom_schedule_service()
            if custom_schedule_service is not None:
                custom_schedule_service.remove_scheduled_getaway(self.uid)
        super().cleanup(from_service_stop=from_service_stop)

    def _validate_guests(self, *_) -> 'bool':
        sim_info_manager = services.sim_info_manager()
        for sim_id in self._guest_sim_ids:
            sim_info = sim_info_manager.get(sim_id)
            if sim_info is None:
                return False
        return True

    def _validate_drama_node(self) -> 'bool':
        if self._zone_id is None or self._household_id is None or self._duration is None:
            return False
        household = services.household_manager().get(self._household_id)
        return self._validate_guests(household)

    def _get_additional_responses(self) -> 'Optional[Tuple[UiDialogResponse, ...]]':
        if services.active_household().get_travel_group():
            return ()
        start_without_me_response = UiDialogResponse(dialog_response_id=self.RESPONSE_ID_START_WITHOUT_ME, text=self.start_without_me_text, disabled_text=None)
        return (start_without_me_response,)

    def _cancel_getaway(self) -> 'None':
        services.custom_schedule_service().remove_scheduled_getaway(self.uid)
        self._schedule_next_occurrence(target_sim_id=self._host_sim_id, household_id=self._household_id, after_timestamp=services.time_service().sim_now, lot_value=self._lot_value)

    def success_response(self, dialog:'UiDialogOkCancel') -> 'None':
        if dialog.response is not None:
            if dialog.response == ButtonType.DIALOG_RESPONSE_OK:
                self._start_travel_group_node()
                self.travel_to_destination()
            if dialog.response == ButtonType.DIALOG_RESPONSE_CANCEL:
                self._cancel_getaway()
            if dialog.response == self.RESPONSE_ID_START_WITHOUT_ME:
                self._start_travel_group_node()
                services.custom_schedule_service().initialize_zone_schedule()
        services.drama_scheduler_service().complete_node(self.uid)

    def error_response(self, dialog:'UiDialogOkCancel') -> 'None':
        if dialog.response == ButtonType.DIALOG_RESPONSE_CANCEL:
            self._cancel_getaway()
            services.drama_scheduler_service().complete_node(self.uid)
            return
        household = services.household_manager().get(self._household_id)
        travel_group_manager = services.travel_group_manager()
        delay_travel = dialog.response == self.RESPONSE_ID_START_WITHOUT_ME
        travel_group = household.get_travel_group()
        if travel_group is not None:
            travel_group.should_skip_travel_on_end = True
            travel_group.safe_sims_after_end = self._guest_sim_ids
            travel_group.end_vacation()
        travel_group = travel_group_manager.get_travel_group_by_zone_id(self._zone_id)
        if travel_group is not None:
            travel_group.end_vacation()
        for response_household in self._household_set:
            travel_group = response_household.get_travel_group()
            if travel_group is not None:
                travel_group.end_vacation()
            travel_group = travel_group_manager.get_travel_group_by_zone_id(response_household.home_zone_id)
            if travel_group is not None:
                travel_group.end_vacation()
        self._start_travel_group_node()
        if dialog.response == ButtonType.DIALOG_RESPONSE_OK:
            self.travel_to_destination()
        if delay_travel:
            services.custom_schedule_service().initialize_zone_schedule()
        services.drama_scheduler_service().complete_node(self.uid)

    def _run(self) -> 'DramaNodeRunOutcome':
        delay_result = self.try_do_travel_dialog_delay(delay_in_minutes=5)
        if delay_result is not None:
            return delay_result
        if not self._validate_drama_node():
            return DramaNodeRunOutcome.FAILURE
        additional_responses = None
        if self._zone_id != services.current_zone_id():
            additional_responses = self._get_additional_responses()
        household = services.household_manager().get(self._household_id)
        (error_strings, self._household_set) = self._get_error_strings_and_household_set(household)
        if error_strings:
            self.show_error_dialog(additional_responses, error_strings)
            return DramaNodeRunOutcome.SUCCESS_NODE_INCOMPLETE
        dialog = self.confirm_dialog(self._receiver_sim_info, resolver=self._get_resolver())
        if additional_responses:
            dialog.set_responses(additional_responses)
        dialog.show_dialog(on_response=self.success_response)
        return DramaNodeRunOutcome.SUCCESS_NODE_INCOMPLETE

    @classproperty
    def drama_node_type(cls) -> 'DramaNodeType':
        return DramaNodeType.GETAWAY

    def get_getaway_schedule(self) -> 'Optional[CustomSchedule]':
        custom_schedule_service = services.custom_schedule_service()
        schedule = custom_schedule_service.get_planned_schedule(self.uid)
        if schedule:
            return schedule
        return self._schedule

    def get_situation_duration_nights(self) -> 'Optional[int]':
        return self._duration

    def _start_travel_group_node(self) -> 'None':
        situation_manager = services.get_zone_situation_manager()
        incompatible_situations = situation_manager.get_user_facing_situations_gen(exclude_compatible_situations=True)
        for situation in tuple(incompatible_situations):
            situation_manager.destroy_situation_by_id(situation.id)
        create_timestamp = self._selected_time
        getaway_schedule = self.get_getaway_schedule()
        if getaway_schedule is None:
            logger.error('No Getaway was found for this drama node')
            return
        travel_group_manager = services.travel_group_manager()
        end_timestamp = self.get_calendar_end_time()
        guest_sim_infos = getaway_schedule.get_siminfos_active_at_time(create_timestamp)
        travel_group_kwargs = {'household_id': self._household_id, 'lot_value': self._lot_value, 'getaway_source_id': self.uid, 'duration': self._duration, 'recurring_days': self._recurring_days, 'start_time': self._start_time, 'end_time': self._end_time}
        travel_group_manager.create_travel_group_and_rent_zone(sim_infos=guest_sim_infos, zone_id=self._zone_id, played=False, create_timestamp=create_timestamp, end_timestamp=end_timestamp, cost=0, getaway_initiator=self._host_sim_id, travel_group_kwargs=travel_group_kwargs)

    @flexmethod
    def travel_to_destination(cls, inst) -> 'None':
        inst_or_cls = cls if inst is None else inst
        getaway_schedule = inst_or_cls.get_getaway_schedule()
        if getaway_schedule is None:
            logger.error('No Getaway was found for this drama node')
            return
        if inst_or_cls._zone_id == services.current_zone_id():
            return
        starting_time_slot = getaway_schedule.get_time_slot_for_hour(inst_or_cls.selected_time.hour())
        available_household_sim_infos = getaway_schedule.get_siminfos_active_in_time_slot(starting_time_slot, active_household_only=True)
        available_household_sim_ids = [sim_info.sim_id for sim_info in available_household_sim_infos]
        travel_sims_to_zone(available_household_sim_ids, inst_or_cls._zone_id)

    def _save_custom_data(self, writer:'PropertyStreamWriter') -> 'None':
        super()._save_custom_data(writer)
        if self._host_sim_id is not None:
            writer.write_uint64(INITIATOR_ID_TOKEN, self._host_sim_id)
        if self._lot_value is not None:
            writer.write_uint32(LOT_VALUE_TOKEN, self._lot_value)
        writer.write_uint64(START_TIME_TOKEN, self._start_time.absolute_ticks())
        writer.write_uint64(END_TIME_TOKEN, self._end_time.absolute_ticks())
        writer.write_uint8s(RECURRING_DAYS_TOKEN, self._recurring_days)

    def _load_custom_data(self, reader:'PropertyStreamReader', skip_behavior_situation:'bool'=True) -> 'bool':
        super_success = super()._load_custom_data(reader, skip_behavior_situation=skip_behavior_situation)
        if not super_success:
            return False
        self._host_sim_id = reader.read_uint64(INITIATOR_ID_TOKEN, None)
        if self._host_sim_id is None:
            return False
        self._lot_value = reader.read_uint32(LOT_VALUE_TOKEN, None)
        self._start_time = DateAndTime(reader.read_uint64(START_TIME_TOKEN, 0))
        self._end_time = DateAndTime(reader.read_uint64(END_TIME_TOKEN, 0))
        self._recurring_days = reader.read_uint8s(RECURRING_DAYS_TOKEN, ())
        return True

    def load(self, drama_node_proto:'PersistableDramaNode', schedule_alarm:'bool'=True, skip_household_loading:'bool'=True) -> 'bool':
        super_success = super().load(drama_node_proto, schedule_alarm=schedule_alarm, skip_household_loading=skip_household_loading)
        if not super_success:
            return False
        household = services.household_manager().get(self._household_id)
        if household is None:
            return False
        if not household.is_active_household:
            return False
        services.calendar_service().mark_on_calendar(self, advance_notice_time=self.get_advance_notice_time())
        return True

    def get_calendar_end_time(self) -> 'DateAndTime':
        if self._end_time != 0:
            return self._end_time
        return self._selected_time + clock.interval_in_sim_days(self._duration)

    def get_calendar_sims(self) -> 'Optional[Iterable[SimInfo]]':
        if not services.active_household():
            return
        else:
            schedule = self.get_getaway_schedule()
            if schedule:
                return schedule.get_siminfos_in_all_time_slots(active_household_only=True)

    def create_calendar_entry(self) -> 'UI_pb2.CalendarEntry':
        calendar_entry = super().create_calendar_entry()
        schedule = self.get_getaway_schedule()
        if schedule.name:
            calendar_entry.getaway_name = schedule.name
        calendar_entry.getaway_duration = self.duration
        calendar_entry.getaway_recurring_days.extend(self.get_recurring_days())
        build_icon_info_msg(IconInfoData(icon_resource=CustomScheduleTuning.SCHEDULE_PLAYER_FACING_SITUATION.calendar_icon), None, calendar_entry.icon_info)
        return calendar_entry

    def create_calendar_alert(self) -> 'Dialog_pb2.UiCalendarMessage':
        calendar_alert = super().create_calendar_alert()
        situation_type = self.get_situation_type()
        calendar_alert.zone_id = self.get_situation_zone_id()
        calendar_alert.show_go_to_button = True
        schedule = self.get_getaway_schedule()
        if situation_type.calendar_alert_description is not None:
            calendar_alert.description = situation_type.calendar_alert_description
        display_name = LocalizationHelperTuning.RAW_TEXT(schedule.name) if schedule and schedule.name else situation_type.display_name
        build_icon_info_msg(IconInfoData(icon_resource=situation_type.calendar_icon), display_name, calendar_alert.calendar_icon)
        return calendar_alert

    def get_source_uid(self) -> 'int':
        return self.uid

    def get_situation_type(self) -> 'Situation':
        return CustomScheduleTuning.SCHEDULE_PLAYER_FACING_SITUATION

    def get_situation_zone_id(self) -> 'int':
        return self._zone_id

    def get_creation_time(self) -> 'DateAndTime':
        return self._start_time

    def get_job_type_to_guest_infos(self) -> 'Iterator[SituationJob, List[SituationGuestInfo]]':
        return dict().items()

    def get_recurring_days(self) -> 'Tuple[int, ...]':
        return self._recurring_days

    def get_end_time(self) -> 'Optional[DateAndTime]':
        return self._end_time
