from __future__ import annotationsimport servicesfrom clubs.club_tuning import ClubRuleCriteriaBase, ClubRuleCriteriaSkill, ClubRuleCriteriaTrait, ClubRuleCriteriaAge, ClubRuleCriteriaFameRank, ClubRuleCriteriaGender, ClubRuleCriteriaRegion, ClubRuleCriteriaOccultTrait, ClubRuleCriteriaCareer, ClubRuleCriteriaRelationshipStatusfrom custom_schedules.custom_schedule_data_classes import ScheduleAssignmentData, CustomScheduleData, ScheduleTimeSlotData, PreselectedGetawayChallengeData, TimeSlotAssignmentData, GetawayChallengeGroupDatafrom custom_schedules.custom_schedule_outfit_tuning import CustomScheduleOutfitVariantfrom sims4 import logfrom sims4.localization import TunableLocalizedStringFactoryfrom sims4.resources import Typesfrom sims4.tuning.instances import HashedTunedInstanceMetaclassfrom sims4.tuning.tunable_base import GroupNamesfrom sims4.tuning.tunable import TunableTuple, Tunable, TunableRange, TunableSet, TunableReference, TunableVariant, TunableMapping, TunablePackSafeReference, OptionalTunable, TunableListlogger = log.Logger('CustomSchedules', default_owner='cparrish')MAX_ASSIGNMENT_RULES = 5MAX_ASSIGNMENT_SIMS = 5
class _SimAssignmentCriteria(TunableTuple):

    def __init__(self, criteria_tunable:'ClubRuleCriteriaBase', disable_required:'bool'=False):
        kwargs = {}
        if disable_required:
            kwargs['locked_args'] = {'criteria_required': False}
        else:
            kwargs['criteria_required'] = Tunable(description='\n                Check if you want the criterion to be required for sims in this CustomScheduleAssignment.\n                ', tunable_type=bool, default=True)
        super().__init__(criteria=criteria_tunable.TunableFactory(), **kwargs)

class CustomScheduleAssignment(metaclass=HashedTunedInstanceMetaclass, manager=services.get_instance_manager(Types.SNIPPET)):
    INSTANCE_TUNABLES = {'display_name': TunableLocalizedStringFactory(description="\n            This Custom Schedule Assignment's name.\n            ", tuning_group=GroupNames.UI), 'sim_count': TunableRange(description='\n            The default number of sims required for this assignment.\n            ', tunable_type=int, default=0, minimum=0, maximum=8), 'default_behaviors': TunableSet(description="\n            The default club rules associated with this assignment. These can be replaced by\n            tuning the optional tunable in a given CustomSchedulePreset's Time Slot Assignment.\n            ", tunable=TunableReference(manager=services.get_instance_manager(Types.CLUB_INTERACTION_GROUP), pack_safe=True), maxlength=MAX_ASSIGNMENT_RULES), 'default_outfit': CustomScheduleOutfitVariant(description='\n            The outfit used for this Assignment. If No Outfit is specified, then\n            no outfit change will be applied.\n            '), 'sim_criteria': TunableSet(description='\n            A set of criteria that all sims in this assignment must pass to be eligible.\n            ', tunable=TunableVariant(age=_SimAssignmentCriteria(ClubRuleCriteriaAge), skill=_SimAssignmentCriteria(ClubRuleCriteriaSkill), gender=_SimAssignmentCriteria(ClubRuleCriteriaGender), region=_SimAssignmentCriteria(ClubRuleCriteriaRegion, disable_required=True), fame_rank=_SimAssignmentCriteria(ClubRuleCriteriaFameRank), trait=_SimAssignmentCriteria(ClubRuleCriteriaTrait), occult_type=_SimAssignmentCriteria(ClubRuleCriteriaOccultTrait), career=_SimAssignmentCriteria(ClubRuleCriteriaCareer), relationship_status=_SimAssignmentCriteria(ClubRuleCriteriaRelationshipStatus), default='skill'), maxlength=MAX_ASSIGNMENT_SIMS)}

    @classmethod
    def _verify_tuning_callback(cls):
        criteria = [criterion.criteria() for criterion in cls.sim_criteria]
        criteria_types = []
        for criterion in criteria:
            if type(criterion) in criteria_types:
                logger.error('You can only have one instance per category. Group up matching {} criteria for {}.', type(criterion), cls)
            criteria_types.append(type(criterion))
        for behavior in cls.default_behaviors:
            if not behavior.custom_schedule_enabled:
                logger.error("Attempting to add a behavior {} to custom schedule assignemnt {} that isn't enabled for custom schedules", behavior, cls)
            elif not behavior.custom_schedule_enabled.activities_rule:
                logger.error("Attempting to add a behavior {} to custom schedule assignemnt {} that isn't enabled for activities", behavior, cls)

    def create_data_class(self) -> 'ScheduleAssignmentData':
        behaviors = [behavior() for behavior in self.default_behaviors] if self.default_behaviors is not None else []
        criteria = []
        display_name_lockey = self.display_name().hash
        assignment_name = str(display_name_lockey)
        for criterion in self.sim_criteria:
            criteria_tuning = criterion.criteria(for_custom_schedules=True)
            criteria_tuning.required = criterion.criteria_required
            criteria.append(criteria_tuning)
        assignment_data = ScheduleAssignmentData(assignment_name, self.sim_count, criteria, behaviors, self.default_outfit(), set(), True, 0, display_name_lockey, False)
        return assignment_data

class CustomSchedulePreset(metaclass=HashedTunedInstanceMetaclass, manager=services.get_instance_manager(Types.SNIPPET)):
    INSTANCE_TUNABLES = {'name': TunableLocalizedStringFactory(description="\n            This Schedule's name.\n            ", tuning_group=GroupNames.UI), 'assignment_hierarchy': TunableList(description='\n            The order of this list dicates the order that roles are displayed AND the order with which\n            we attempt to automatically place the active household sim into based on assignment criteria.\n            ', tunable=TunablePackSafeReference(description='\n                A pre-made CustomScheduleAssignment.\n                ', manager=services.get_instance_manager(Types.SNIPPET), class_restrictions=('CustomScheduleAssignment',))), 'time_slots': TunableMapping(description='\n            A tunable mapping from hour offset of the start of a day that will be applied at that hour every day.\n            ', key_type=TunableRange(description='\n                The range of hours in a day.\n                ', tunable_type=int, minimum=0, maximum=23, default=0), value_type=TunableTuple(default_behavior=TunablePackSafeReference(description="\n                    The default ClubInteractionGroup used for this time slot if a Time Slot Assignment's\n                    interactions are unavailable.\n                    ", manager=services.get_instance_manager(Types.CLUB_INTERACTION_GROUP), allow_none=True), time_slot_assignments=TunableMapping(key_type=TunablePackSafeReference(description='\n                        The pre-made CustomScheduleAssignment used for this time slot assignment.\n                        ', manager=services.get_instance_manager(Types.SNIPPET), class_restrictions=('CustomScheduleAssignment',)), value_type=TunableTuple(description="\n                        Data for a given 'Assignment' during a given time slot.\n                        ", sim_count_override=OptionalTunable(description='\n                            If enabled, this will override the "sim count" tuned on the\n                            associated CustomScheduleAssignment.\n                            ', tunable=TunableRange(tunable_type=int, default=0, minimum=0, maximum=8)), outfit_override=OptionalTunable(description='\n                            If enabled, this will override the "default outfit" tuned on\n                            the associated CustomScheduleAssignment.\n                            ', tunable=CustomScheduleOutfitVariant(uniform_disabled=True)), behavior_overrides=OptionalTunable(description='\n                            If enabled, this will override the "default behaviors" tuned on\n                            the associated CustomScheduleAssignment.\n                            ', tunable=TunableSet(description='\n                                ClubInteractionGroups to use instead of the CustomScheduleAssignment\'s "default behaviors".\n                                ', tunable=TunableReference(manager=services.get_instance_manager(Types.CLUB_INTERACTION_GROUP), pack_safe=True), maxlength=MAX_ASSIGNMENT_RULES)))))), 'preselected_getaway_challenges': TunableList(description='\n            A list of all challenges automatically applied to a Premade Getaway.\n            ', tunable=TunableTuple(description='\n                A challenge paired with CustomScheduleAssignment(s) deemed "of_interest" and "participating".\n                ', challenge=TunableReference(description='\n                    The Getaway Challenge to be automatically applied when scheduling a getaway with this schedule.\n                    ', manager=services.get_instance_manager(Types.GETAWAY_CHALLENGE)), assigned_groups=TunableList(description="\n                    This mirrors 'GetawayChallenge' groups. Assign each CustomScheduleAssignment\n                    to the group index you expect the assignment to auto-fill into.\n                    ", tunable=TunableList(TunableReference(description="\n                        A CustomScheduleAssignment that auto-fills into this index's group within\n                        the Getaway Challenge.\n                        ", manager=services.get_instance_manager(Types.SNIPPET), class_restrictions=('CustomScheduleAssignment',))))), unique_entries=True)}

    @classmethod
    def _verify_tuning_callback(cls):
        for (time, time_slot) in cls.time_slots.items():
            behavior = time_slot.default_behavior
            if behavior is not None:
                if not behavior.custom_schedule_enabled:
                    logger.error("Attempting to add a behavior {} to time slot {} in schedule {} that isn't enabled for custom schedules", behavior, time, cls)
                else:
                    if not behavior.custom_schedule_enabled.behavior_rule:
                        logger.error("Attempting to add a behavior {} to time slot {} in schedule {} that isn't enabled for behaviors", behavior, time, cls)
                    for (assignment, time_slot_assignment) in time_slot.time_slot_assignments.items():
                        if time_slot_assignment.behavior_overrides:
                            for behavior in time_slot_assignment.behavior_overrides:
                                if not behavior.custom_schedule_enabled:
                                    logger.error("Attempting to add a behavior {} to assignemnt {} in time slot {} for schedule {} that isn't enabled for custom schedules", behavior, assignment, time, cls)
                                elif not behavior.custom_schedule_enabled.activities_rule:
                                    logger.error("Attempting to add a behavior {} to assignemnt {} in time slot {} for schedule {} that isn't enabled for activities", behavior, assignment, time, cls)
            for (assignment, time_slot_assignment) in time_slot.time_slot_assignments.items():
                if time_slot_assignment.behavior_overrides:
                    for behavior in time_slot_assignment.behavior_overrides:
                        if not behavior.custom_schedule_enabled:
                            logger.error("Attempting to add a behavior {} to assignemnt {} in time slot {} for schedule {} that isn't enabled for custom schedules", behavior, assignment, time, cls)
                        elif not behavior.custom_schedule_enabled.activities_rule:
                            logger.error("Attempting to add a behavior {} to assignemnt {} in time slot {} for schedule {} that isn't enabled for activities", behavior, assignment, time, cls)

    def create_data_class(self) -> 'CustomScheduleData':
        assignment_tuning_presets = dict()
        assignment_preset_ids = dict()
        preselected_getaway_challenges = []
        time_slots = []
        schedule_name = str(self.name().hash)
        for (assignment_id, assignment_tuning) in enumerate(self.assignment_hierarchy):
            assignment_data = assignment_tuning().create_data_class()
            assignment_data.id = assignment_id
            assignment_name = str(assignment_data.display_name_lockey)
            assignment_tuning_presets[assignment_name] = assignment_data
            assignment_preset_ids[assignment_tuning] = assignment_id
        for (start_time, time_slot) in self.time_slots.items():
            time_slot_assignments = []
            for (assignment, overrides) in time_slot.time_slot_assignments.items():
                assignment_data = assignment().create_data_class()
                assignment_name = str(assignment_data.display_name_lockey)
                if assignment_name not in assignment_tuning_presets.keys():
                    logger.error("Time Slot @{} Assignment {} isn't in the assignment hierarchy for {}", start_time, assignment, self)
                else:
                    assignment_data = assignment_tuning_presets[assignment_name]
                    override_behaviors = []
                    if overrides.behavior_overrides is not None:
                        override_behaviors = [behavior() for behavior in overrides.behavior_overrides]
                    override_outfit = overrides.outfit_override() if overrides.outfit_override is not None else None
                    override_data = ScheduleAssignmentData(assignment_name, overrides.sim_count_override, set(), override_behaviors, override_outfit, set(), False, assignment_data.id, assignment_data.display_name_lockey, False)
                    time_slot_assignment = TimeSlotAssignmentData(assignment_data.id, override_data, overrides.behavior_overrides is not None, False, override_data.outfit is not None, override_data.sim_count is not None)
                    time_slot_assignments.append(time_slot_assignment)
            default_behavior = time_slot.default_behavior() if time_slot.default_behavior is not None else None
            this_time_slot = ScheduleTimeSlotData(start_time, time_slot_assignments, default_behavior, None)
            time_slots.append(this_time_slot)
        for challenge_tuning in self.preselected_getaway_challenges:
            assigned_groups = list()
            for preselected_group in challenge_tuning.assigned_groups:
                category_id = len(assigned_groups) + 1
                assignment_ids = list()
                for preselected_assignment in preselected_group:
                    if preselected_assignment in assignment_preset_ids:
                        assignment_ids.append(assignment_preset_ids[preselected_assignment])
                    else:
                        logger.error('Challenge {} has group using assignment preset {} not in CustomSchedulePreset.', challenge_tuning, preselected_assignment, owner='jmoline')
                tuning_defined_group = GetawayChallengeGroupData(category_id, list(), assignment_ids)
                assigned_groups.append(tuning_defined_group)
            tuning_defined_selection = PreselectedGetawayChallengeData(challenge_tuning.challenge.guid64, assigned_groups)
            preselected_getaway_challenges.append(tuning_defined_selection)
        assignment_presets = list(assignment_tuning_presets.values())
        assignment_presets.sort(key=lambda _assignment: _assignment.id)
        time_slots.sort(key=lambda _time_slot: _time_slot.start_time)
        schedule_data = CustomScheduleData(schedule_name, assignment_presets, time_slots, True, preselected_getaway_challenges, self.name().hash, False)
        return schedule_data
