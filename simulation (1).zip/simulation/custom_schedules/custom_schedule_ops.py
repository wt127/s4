import servicesimport sims4from interactions import ParticipantTypeSingleSimfrom interactions.utils.interaction_elements import XevtTriggeredElementfrom sims4.tuning.tunable import TunableEnumEntry, Tunablelogger = sims4.log.Logger('CustomScheduleOps', default_owner='cparrish')
class RemoveFromSchedule(XevtTriggeredElement):
    FACTORY_TUNABLES = {'subject': TunableEnumEntry(description='\n            The Sim that will be removed from the CustomSchedule.\n            ', tunable_type=ParticipantTypeSingleSim, default=ParticipantTypeSingleSim.Actor), 'decrement_sim_count': Tunable(description="\n            Lower the total number of allowed sims in that sim's assignment across all time slots.\n            ", tunable_type=bool, default=False), 'penalize_host': Tunable(description="\n            If enabled, and if the active household are hosting the getaway on their active lot,\n            the host's profit loop will be penalized due to the sim leaving.\n            ", tunable_type=bool, default=False), 'prevent_sim_from_returning': Tunable(description='\n            Prevents the sim from getting auto-filled again for the duration of the Getaway.\n            ', tunable_type=bool, default=False)}

    def _do_behavior(self, *args, **kwargs) -> None:
        subject = self.interaction.get_participant(self.subject)
        if subject is None:
            logger.error('RemoveFromSchedule: Trying to remove a non-existent Sim from a CustomSchedule')
            return
        custom_schedule_service = services.custom_schedule_service()
        if custom_schedule_service is None:
            logger.error('RemoveFromSchedule: The CustomScheduleService is unavailable.')
            return
        active_schedule = custom_schedule_service.active_getaway_schedule
        if active_schedule is None:
            logger.error('RemoveFromSchedule: There is no active schedule.')
            return
        travel_group = active_schedule.getaway_travel_group
        if travel_group is not None:
            travel_group.remove_sim_info(subject.sim_info, decrement_sim_count=self.decrement_sim_count, blocklist_sim=self.prevent_sim_from_returning)
        if self.penalize_host:
            active_household = services.active_household()
            travel_group = active_household.get_travel_group()
            if travel_group.zone_id != active_household.home_zone_id:
                return
            travel_group.penalize_profit_loop()
