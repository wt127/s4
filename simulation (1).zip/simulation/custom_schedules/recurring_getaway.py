from __future__ import annotationsimport date_and_timeimport servicesfrom custom_schedules.custom_schedule_tuning import CustomScheduleTuningfrom situations.situation_edit import SituationEditablefrom situations.situation_guest_list import SituationGuestListfrom typing import TYPE_CHECKINGif TYPE_CHECKING:
    from date_and_time import DateAndTime
class RecurringGetawayMixin(SituationEditable):

    def _schedule_next_occurrence(self, target_sim_id:'int', household_id:'int', after_timestamp:'DateAndTime', lot_value:'int') -> 'None':
        recurring_days = self.get_recurring_days()
        if not recurring_days:
            return
        reference_time = self.get_creation_time()
        elapsed_weeks = (after_timestamp - reference_time).in_weeks()
        if elapsed_weeks >= 1:
            reference_time += date_and_time.create_time_span(days=int(elapsed_weeks)*date_and_time.DAYS_PER_WEEK)
        current_day = int(reference_time.day())
        repeat_interval = None
        for day in recurring_days:
            start_interval = date_and_time.create_time_span(days=(day - current_day + date_and_time.DAYS_PER_WEEK) % date_and_time.DAYS_PER_WEEK)
            check_timestamp = reference_time + start_interval
            if check_timestamp <= after_timestamp:
                pass
            else:
                if not repeat_interval is None:
                    if start_interval < repeat_interval:
                        repeat_interval = start_interval
                repeat_interval = start_interval
        if repeat_interval is not None:
            target_sim = services.sim_info_manager().get(target_sim_id)
            if target_sim and target_sim.household_id == household_id:
                start_timestamp = reference_time + repeat_interval
                end_time = self.get_end_time()
                end_timestamp = end_time + repeat_interval if end_time != 0 else 0
                self._schedule_recurrence(target_sim_id, household_id, start_timestamp, end_timestamp, lot_value)

    def _schedule_recurrence(self, target_sim_id:'int', household_id:'int', start_timestamp:'DateAndTime', end_timestamp:'DateAndTime', lot_value:'int') -> 'None':
        zone_id = self.get_situation_zone_id()
        schedule = self.get_getaway_schedule()
        drama_node_schedule_kwargs = {'zone_id': zone_id, 'household_id': household_id, 'duration': self.get_situation_duration_nights(), 'guest_sim_ids': [guest_sim_info.id for guest_sim_info in schedule.get_siminfos_active_at_time(start_timestamp)], 'host_sim_id': target_sim_id, 'lot_value': lot_value, 'schedule': schedule, 'start_time': start_timestamp, 'end_time': end_timestamp, 'recurring_days': self.get_recurring_days()}
        situation_manager = services.get_zone_situation_manager()
        situation_manager.create_situation(CustomScheduleTuning.SCHEDULE_PLAYER_FACING_SITUATION, guest_list=SituationGuestList(True, target_sim_id), zone_id=zone_id, scoring_enabled=False, scheduled_time=start_timestamp, drama_node_kwargs=drama_node_schedule_kwargs)
