from __future__ import annotationsimport servicesfrom buffs.appearance_modifier.appearance_modifier import AppearanceModifierfrom cas.cas import get_caspart_bodytypefrom custom_schedules.custom_schedule_tuning import CustomScheduleTuningfrom event_testing.resolver import SingleSimResolverfrom event_testing.tests import TunableTestSetimport randomfrom sims.global_gender_preference_tuning import GlobalGenderPreferenceTuningfrom sims.outfits import outfit_utilsfrom sims.outfits.outfit_generator import TunableOutfitGeneratorReference, OutfitGeneratorfrom sims.sim_info_types import Age, Genderfrom sims4.log import Loggerfrom typing import TYPE_CHECKINGfrom sims.sim_info_base_wrapper import SimInfoBaseWrapperif TYPE_CHECKING:
    from protocolbuffers import SimObjectAttributes_pb2
    from sims.sim_info import SimInfo
    from typing import List, Optional, Set, Tupleimport enumfrom sims.outfits.outfit_enums import OutfitCategory, CLOTHING_BODY_TYPESfrom sims4.resources import Typesfrom sims4.tuning.tunable import HasTunableFactory, AutoFactoryInit, OptionalTunable, TunableEnumWithFilter, TunableEnumEntry, TunablePackSafeResourceKey, TunableVariant, TunableMapping, TunableTuple, TunableListfrom tag import Tagfrom protocolbuffers import CustomSchedule_pb2logger = Logger('CustomSchedules', default_owner='cparrish')
class CustomScheduleOutfitSetting(enum.Int):
    NO_OUTFIT = 0
    CATEGORY = 1
    STYLE_COLOR = 2
    OVERRIDE = 3

class CustomScheduleOutfitTuning:
    OUTFIT_CATEGORY_MAPPING = TunableMapping(description='\n        Used to manually push sims into certain categories.\n        ', key_type=OutfitCategory, value_type=TunableList(description='\n            A collection of testable generators used for generating outfits based on style & color.\n            ', tunable=TunableTuple(description='\n                Set of outfit generator and tests that will \n                be run on the sim to validate if the generator \n                is valid for this outfit.\n                ', generator=TunableOutfitGeneratorReference(pack_safe=True), tests=TunableTestSet(description='\n                    Test set the sim will need to pass to be able to wear the outfit\n                    corresponding to the tuned tags. For a given category, the generator\n                    should include an "OutfitCategory" in it\'s Tags to match the intent.\n                    \n                    NOTE: Using the additional "OutfitCategory" tag will restrict acceptable\n                    CAS items. If you\'re unhappy with the generated outfits, you should \n                    consider testing for if a Style tag has been chosen and if so, using a \n                    generator without the specified OutfitCategory. This is more noticeable\n                    with less active packs.\n                    '))))
    OUTFIT_CATEGORIES_THAT_IGNORE_OUTFIT_SETTINGS = {OutfitCategory.SWIMWEAR, OutfitCategory.BATHING}

class CustomScheduleOutfitVariant(TunableVariant):

    def __init__(self, *args, uniform_disabled=False, **kwargs):
        if not uniform_disabled:
            kwargs['uniform'] = CustomScheduleUniformSetting.TunableFactory()
        super().__init__(no_outfit=CustomScheduleNoOutfitSetting.TunableFactory(), style_and_color=CustomScheduleStyleAndColorSetting.TunableFactory(), outfit_category=CustomScheduleCategorySetting.TunableFactory(), default='no_outfit', **kwargs)

class _BaseCustomScheduleOutfit(HasTunableFactory, AutoFactoryInit):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def populate_proto(self, msg:'CustomSchedule_pb2.ScheduleAssignmentOutfit') -> 'None':
        raise NotImplementedError

    def get_outfit_setting(self) -> 'CustomScheduleOutfitSetting':
        raise NotImplementedError

    def should_spin_into_outfit(self, sim_info:'SimInfo') -> 'bool':
        current_outfit = sim_info.get_current_outfit()
        if current_outfit[0] == OutfitCategory.BATHING:
            return False
        tests = CustomScheduleTuning.CAN_CHANGE_OUTFIT_TESTS
        if not tests:
            return True
        resolver = SingleSimResolver(sim_info)
        return tests.run_tests(resolver)

    def _get_outfit_parts(self, sim_info:'SimInfo', outfit_category:'OutfitCategory', template_sim_info:'SimInfo', target_category:'Optional[int]'=None, target_index:'Optional[int]'=None) -> 'Tuple[List, List]':
        to_add = []
        to_remove = []
        if target_index is None:
            (target_category, target_index) = template_sim_info.get_random_outfit(outfit_categories=(outfit_category,))
        if target_category is None and target_category != outfit_category or not template_sim_info.has_outfit((target_category, target_index)):
            return (to_add, to_remove)
        outfit_data = template_sim_info.get_outfit(target_category, target_index)
        to_add.extend(part_id for part_id in outfit_data.part_ids if get_caspart_bodytype(part_id) in CLOTHING_BODY_TYPES)
        for outfit in sim_info.get_outfits_in_category(outfit_category):
            for part in outfit.part_ids:
                body_type = get_caspart_bodytype(part)
                if body_type in CLOTHING_BODY_TYPES and body_type not in outfit_data.body_types:
                    to_remove.append(part)
        return (to_add, to_remove)

    def apply_outfit(self, sim_info:'SimInfo', outfit_category_and_index:'Tuple[OutfitCategory, int]', old_outfit_category_and_index:'Tuple[OutfitCategory, int]', appearance_modifier_uid:'int') -> 'None':
        appearance_tracker = sim_info.appearance_tracker
        appearance_tracker.remove_appearance_modifiers(appearance_modifier_uid, source=self)
        (outfit_category, outfit_index) = outfit_category_and_index
        (cas_parts_add, cas_parts_remove) = self._get_outfit_parts(sim_info, outfit_category, sim_info)
        modifiers = []
        for cas_part in cas_parts_add:
            modifier = AppearanceModifier.SetCASPart(cas_part=cas_part, should_toggle=False, replace_with_random=False, update_genetics=False, _is_combinable_with_same_type=True, remove_conflicting=False, outfit_type_compatibility=None, appearance_modifier_tag=None, expect_invalid_parts=False, hsv_color_shift=None, object_id=0, part_layer_index=-1, rgba_color_shift=None, should_refresh_thumbnail=False)
            modifiers.append(modifier)
        for cas_part in cas_parts_remove:
            modifier = AppearanceModifier.SetCASPart(cas_part=cas_part, should_toggle=True, replace_with_random=False, update_genetics=False, _is_combinable_with_same_type=True, remove_conflicting=False, outfit_type_compatibility=None, appearance_modifier_tag=None, expect_invalid_parts=False, hsv_color_shift=None, object_id=0, part_layer_index=-1, rgba_color_shift=None, should_refresh_thumbnail=False)
            modifiers.append(modifier)
        for modifier in modifiers:
            appearance_tracker.add_appearance_modifier(modifier, appearance_modifier_uid, 1, False, source=self)
        appearance_tracker.evaluate_appearance_modifiers()
        if appearance_tracker.appearance_override_sim_info is not None:
            sim = sim_info.get_sim_instance()
            if sim is not None:
                sim.apply_outfit_buffs_for_sim_info(appearance_tracker.appearance_override_sim_info, (outfit_category, outfit_index))

class CustomScheduleUniformSetting(_BaseCustomScheduleOutfit):
    FACTORY_TUNABLES = {'masculine_adult': OptionalTunable(TunablePackSafeResourceKey(description='\n            A uniform for masculine TYAE in this time slot.\n            ', resource_types=(Types.SIMINFO,))), 'masculine_child': OptionalTunable(TunablePackSafeResourceKey(description='\n            A uniform for masculine children in this time slot.\n            ', resource_types=(Types.SIMINFO,))), 'feminine_adult': OptionalTunable(TunablePackSafeResourceKey(description='\n            A uniform for feminine TYAE in this time slot.\n            ', resource_types=(Types.SIMINFO,))), 'feminine_child': OptionalTunable(TunablePackSafeResourceKey(description='\n            A uniform for feminine children in this time slot.\n            ', resource_types=(Types.SIMINFO,)))}

    def _is_valid_mannequin(self, mannequin:'Optional[SimObjectAttributes_pb2.MannequinSimData]') -> 'bool':
        if mannequin is None:
            return False
        return mannequin.age != 0 and mannequin.gender != 0

    def __init__(self, *args, masculine_adult_mannequin:'Optional[SimObjectAttributes_pb2.MannequinSimData]'=None, masculine_child_mannequin:'Optional[SimObjectAttributes_pb2.MannequinSimData]'=None, feminine_adult_mannequin:'Optional[SimObjectAttributes_pb2.MannequinSimData]'=None, feminine_child_mannequin:'Optional[SimObjectAttributes_pb2.MannequinSimData]'=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.masculine_adult_mannequin = None
        self.feminine_adult_mannequin = None
        self.masculine_child_mannequin = None
        self.feminine_child_mannequin = None
        custom_schedule_service = services.custom_schedule_service()
        if custom_schedule_service is None:
            return
        mannequin_id = custom_schedule_service.mannequin_id
        if self._is_valid_mannequin(masculine_adult_mannequin):
            self.masculine_adult_mannequin = SimInfoBaseWrapper(sim_id=mannequin_id)
            self.masculine_adult_mannequin.load_sim_info(masculine_adult_mannequin)
        if self._is_valid_mannequin(masculine_child_mannequin):
            self.masculine_child_mannequin = SimInfoBaseWrapper(sim_id=mannequin_id)
            self.masculine_child_mannequin.load_sim_info(masculine_child_mannequin)
        if self._is_valid_mannequin(feminine_adult_mannequin):
            self.feminine_adult_mannequin = SimInfoBaseWrapper(sim_id=mannequin_id)
            self.feminine_adult_mannequin.load_sim_info(feminine_adult_mannequin)
        if self._is_valid_mannequin(feminine_child_mannequin):
            self.feminine_child_mannequin = SimInfoBaseWrapper(sim_id=mannequin_id)
            self.feminine_child_mannequin.load_sim_info(feminine_child_mannequin)

    def populate_proto(self, msg:'CustomSchedule_pb2.ScheduleAssignmentOutfit') -> 'None':
        msg.outfit_setting = self.get_outfit_setting()
        if self.masculine_adult is not None and self.masculine_adult_mannequin is None:
            self._get_uniform_data(Age.ADULT, Gender.MALE)
        if self.masculine_adult_mannequin is not None:
            self.masculine_adult_mannequin.save_sim_info(msg.assignment_uniform_adult_male)
        if self.feminine_adult is not None and self.feminine_adult_mannequin is None:
            self._get_uniform_data(Age.ADULT, Gender.FEMALE)
        if self.feminine_adult_mannequin is not None:
            self.feminine_adult_mannequin.save_sim_info(msg.assignment_uniform_adult_female)
        if self.masculine_child is not None and self.masculine_child_mannequin is None:
            self._get_uniform_data(Age.CHILD, Gender.MALE)
        if self.masculine_child_mannequin is not None:
            self.masculine_child_mannequin.save_sim_info(msg.assignment_uniform_child_male)
        if self.feminine_child is not None and self.feminine_child_mannequin is None:
            self._get_uniform_data(Age.CHILD, Gender.FEMALE)
        if self.feminine_child_mannequin is not None:
            self.feminine_child_mannequin.save_sim_info(msg.assignment_uniform_child_female)

    def get_outfit_setting(self) -> 'CustomScheduleOutfitSetting':
        return CustomScheduleOutfitSetting.OVERRIDE

    def should_spin_into_outfit(self, sim_info:'SimInfo') -> 'bool':
        super_success = super().should_spin_into_outfit(sim_info)
        if not super_success:
            return False
        (current_outfit_category, _) = sim_info.get_current_outfit()
        mannequin_data = self._get_uniform_data(sim_info.age, sim_info.clothing_preference_gender)
        return mannequin_data.has_outfit((current_outfit_category, 0))

    def _get_uniform_data(self, age:'Age', gender:'Gender') -> 'SimInfoBaseWrapper':
        custom_schedule_service = services.custom_schedule_service()
        mannequin_id = custom_schedule_service.mannequin_id
        if age != Age.CHILD and gender is Gender.MALE:
            if self.masculine_adult_mannequin is None:
                self.masculine_adult_mannequin = SimInfoBaseWrapper(sim_id=mannequin_id)
                resource = self.masculine_adult or CustomScheduleTuning.DEFAULT_MANNEQUIN_DATA.male_adult
                self.masculine_adult_mannequin.load_from_resource(resource)
            return self.masculine_adult_mannequin
        if age != Age.CHILD and gender is Gender.FEMALE:
            if self.feminine_adult_mannequin is None:
                self.feminine_adult_mannequin = SimInfoBaseWrapper(sim_id=mannequin_id)
                resource = self.feminine_adult or CustomScheduleTuning.DEFAULT_MANNEQUIN_DATA.female_adult
                self.feminine_adult_mannequin.load_from_resource(resource)
            return self.feminine_adult_mannequin
        if age is Age.CHILD and gender is Gender.MALE:
            if self.masculine_child_mannequin is None:
                self.masculine_child_mannequin = SimInfoBaseWrapper(sim_id=mannequin_id)
                resource = self.masculine_child or CustomScheduleTuning.DEFAULT_MANNEQUIN_DATA.male_child
                self.masculine_child_mannequin.load_from_resource(resource)
            return self.masculine_child_mannequin
        elif age is Age.CHILD and gender is Gender.FEMALE:
            if self.feminine_child_mannequin is None:
                self.feminine_child_mannequin = SimInfoBaseWrapper(sim_id=mannequin_id)
                resource = self.feminine_child or CustomScheduleTuning.DEFAULT_MANNEQUIN_DATA.female_child
                self.feminine_child_mannequin.load_from_resource(resource)
            return self.feminine_child_mannequin

    def _get_outfit_parts(self, sim_info:'SimInfo', outfit_category:'OutfitCategory', _, **__) -> 'Tuple[List, List]':
        mannequin_data = self._get_uniform_data(sim_info.age, sim_info.clothing_preference_gender)
        return super()._get_outfit_parts(sim_info, outfit_category, mannequin_data)

class CustomScheduleCategorySetting(_BaseCustomScheduleOutfit):
    FACTORY_TUNABLES = {'outfit_category': TunableEnumEntry(description='\n            The outfit category to use.\n            ', tunable_type=OutfitCategory, default=OutfitCategory.EVERYDAY, invalid_enums=(OutfitCategory.SITUATION, OutfitCategory.SMALL_BUSINESS))}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def populate_proto(self, msg:'CustomSchedule_pb2.ScheduleAssignmentOutfit') -> 'None':
        msg.outfit_setting = self.get_outfit_setting()
        msg.outfit_category = self.outfit_category

    def get_outfit_setting(self) -> 'CustomScheduleOutfitSetting':
        return CustomScheduleOutfitSetting.CATEGORY

    def should_spin_into_outfit(self, sim_info:'SimInfo') -> 'bool':
        super_success = super().should_spin_into_outfit(sim_info)
        if not super_success:
            return False
        (current_outfit_category, _) = sim_info.get_current_outfit()
        return current_outfit_category != self.outfit_category

    def _get_outfit_parts(self, sim_info:'SimInfo', outfit_category:'OutfitCategory', _, **__) -> 'Tuple[List, List]':
        if outfit_category in CustomScheduleOutfitTuning.OUTFIT_CATEGORIES_THAT_IGNORE_OUTFIT_SETTINGS:
            return ([], [])
        return super()._get_outfit_parts(sim_info, self.outfit_category, sim_info)

class CustomScheduleStyleAndColorSetting(_BaseCustomScheduleOutfit):
    FACTORY_TUNABLES = {'style': OptionalTunable(description='\n            The desired style tag for the outfit.\n            ', tunable=TunableEnumWithFilter(description='\n                A style tag used to find matching CAS parts.\n                ', tunable_type=Tag, default=Tag.INVALID, filter_prefixes=('style',), pack_safe=True)), 'color': OptionalTunable(description='\n            The desired color tag for the outfit.\n            ', tunable=TunableEnumWithFilter(description='\n                A color tag used to find matching CAS parts.\n                ', tunable_type=Tag, default=Tag.INVALID, filter_prefixes=('color',), pack_safe=True))}

    def __init__(self, *args, style:'Optional[int]'=None, color:'Optional[int]'=None, style_enabled:'bool'=True, color_enabled:'bool'=True, **kwargs):
        if not style_enabled:
            style = None
        if not color_enabled:
            color = None
        super().__init__(*args, style=style, color=color, **kwargs)

    def populate_proto(self, msg:'CustomSchedule_pb2.ScheduleAssignmentOutfit') -> 'None':
        msg.outfit_setting = self.get_outfit_setting()
        if self.color:
            msg.outfit_color = self.color
        if self.style:
            msg.outfit_style = self.style
        msg.style_enabled = bool(self.style)
        msg.color_enabled = bool(self.color)

    def get_outfit_setting(self):
        return CustomScheduleOutfitSetting.STYLE_COLOR

    def should_spin_into_outfit(self, sim_info:'SimInfo') -> 'bool':
        super_success = super().should_spin_into_outfit(sim_info)
        if not super_success:
            return False
        return self.style is not None or self.color is not None

    def _get_required_tags(self, sim_info:'SimInfo') -> 'Set':
        required_tags = set()
        if self.style:
            required_tags.add(self.style)
        if self.color:
            required_tags.add(self.color)
        preference = sim_info.clothing_preference_gender
        gendered_clothing_tag = GlobalGenderPreferenceTuning.GENDERED_CLOTHING_PREFERENCE_TAGS.get(preference, None)
        if gendered_clothing_tag:
            required_tags.add(gendered_clothing_tag)
        return required_tags

    def _search_for_valid_outfit(self, sim_info:'SimInfo', outfit_category:'OutfitCategory', generators:'List[OutfitGenerator]') -> 'Tuple[OutfitCategory, int]':
        required_tags = self._get_required_tags(sim_info)
        valid_outfit = outfit_utils.check_outfit_validity(sim_info, required_tags, generators, OutfitCategory.SITUATION, 0)
        if valid_outfit:
            return (OutfitCategory.SITUATION, 0)
        for (outfit_index, _) in enumerate(sim_info.get_outfits_in_category(outfit_category)):
            valid_outfit = outfit_utils.check_outfit_validity(sim_info, required_tags, generators, outfit_category, outfit_index)
            if valid_outfit:
                return (outfit_category, outfit_index)
        return (OutfitCategory.SITUATION, -1)

    def _get_outfit_parts(self, sim_info:'SimInfo', outfit_category:'OutfitCategory', _, **kwargs) -> 'Tuple[List, List]':
        generators = CustomScheduleOutfitTuning.OUTFIT_CATEGORY_MAPPING.get(outfit_category, None)
        if generators is None:
            logger.error('No outfit generator was tuned for the {} category.', outfit_category)
            return ([], [])
        (outfit_category, valid_outfit_index) = self._search_for_valid_outfit(sim_info, outfit_category, generators)
        if valid_outfit_index != -1:
            used_outfit = (outfit_category, valid_outfit_index)
            sim_info.generate_merged_outfit(sim_info, (OutfitCategory.SITUATION, 0), used_outfit, used_outfit)
        else:
            outfit_generators_test = list(generators)
            tested_outfit_generator = None
            valid_generator = False
            resolver = SingleSimResolver(sim_info)
            while outfit_generators_test and not valid_generator:
                tested_outfit_generator = random.choice(outfit_generators_test)
                if not tested_outfit_generator.tests.run_tests(resolver):
                    outfit_generators_test.remove(tested_outfit_generator)
                else:
                    valid_generator = True
            if valid_generator:
                OutfitGenerator.generate_outfit(tested_outfit_generator, sim_info, OutfitCategory.SITUATION, outfit_extra_tag_set=self._get_required_tags(sim_info), outfit_index=0)
            else:
                logger.error('There were no valid outfit generators for the Sim {}. Check tuning tests.', sim_info)
                return ([], [])
        return super()._get_outfit_parts(sim_info, outfit_category, sim_info, target_category=OutfitCategory.SITUATION, target_index=0)

class CustomScheduleNoOutfitSetting(_BaseCustomScheduleOutfit):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def should_spin_into_outfit(self, sim_info:'SimInfo') -> 'bool':
        return False

    def populate_proto(self, msg:'CustomSchedule_pb2.ScheduleAssignmentOutfit') -> 'None':
        msg.outfit_setting = self.get_outfit_setting()

    def get_outfit_setting(self):
        return CustomScheduleOutfitSetting.NO_OUTFIT

    def apply_outfit(self, *args, **kwargs) -> 'None':
        pass
