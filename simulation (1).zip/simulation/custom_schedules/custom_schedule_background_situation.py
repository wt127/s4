from __future__ import annotationsimport servicesfrom event_testing.resolver import SingleSimResolverfrom sims4.utils import classpropertyfrom situations.situation import Situationfrom typing import TYPE_CHECKINGif TYPE_CHECKING:
    from situations.situation_job import SituationJob
    from situations.situation_serialization import SituationSeed
    from typing import List, Tuplefrom situations.situation_complex import SituationState, SituationComplexCommon, SituationStateData, TunableSituationJobAndRoleState
class _DefaultSituationState(SituationState):
    pass

class CustomScheduleBackgroundSituation(SituationComplexCommon):
    INSTANCE_TUNABLES = {'participant_job_and_role_state': TunableSituationJobAndRoleState(description='\n            Job and Role State for the participant.\n            ')}
    REMOVE_INSTANCE_TUNABLES = ('activity_selection', 'minimum_activities_required', 'display_special_object', 'customizable_style') + Situation.NON_USER_FACING_REMOVE_INSTANCE_TUNABLES

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    @classmethod
    def _states(cls) -> 'Tuple[SituationStateData, ...]':
        return (SituationStateData(1, _DefaultSituationState),)

    @classmethod
    def _get_tuned_job_and_default_role_state_tuples(cls) -> 'List':
        return [(cls.participant_job_and_role_state.job, cls.participant_job_and_role_state.role_state)]

    @classmethod
    def default_job(cls) -> 'SituationJob':
        return cls.participant_job_and_role_state.job

    @classmethod
    def should_seed_be_loaded(cls, seed:'SituationSeed', load_open_street_situation_with_selectable_sim:'bool'=False) -> 'bool':
        return False

    def _resolve_sim_job_headline(self, sim, sim_job, removed_situation=None):
        resolver = SingleSimResolver(sim.sim_info)
        tokens = sim_job.tooltip_name_text_tokens.get_tokens(resolver)
        active_schedule = services.custom_schedule_service().active_schedule
        if active_schedule is None or removed_situation is not None and removed_situation.guid64 == self.guid64:
            return tokens
        if sim_job.user_facing_sim_headline_display_override:
            sim.sim_info.sim_headline = sim_job.tooltip_name(*tokens)
        return tokens

    def start_situation(self) -> 'None':
        super().start_situation()
        self._change_state(_DefaultSituationState())

    @classproperty
    def always_elevated_importance(cls):
        return True
