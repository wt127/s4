from drama_scheduler.festival_contest_drama_node_mixin import FestivalContestDramaNodeMixinfrom drama_scheduler.festival_drama_node import FestivalDramaNode
class FestivalContestDramaNode(FestivalContestDramaNodeMixin, FestivalDramaNode):
    pass
