
class AutonomyExitException(Exception):
    pass
