import enum
class BusinessRuleState(enum.Int):
    DISABLED = 0
    ENABLED = 1
    BROKEN = 2
